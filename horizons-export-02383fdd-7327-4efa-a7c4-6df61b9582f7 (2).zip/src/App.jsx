import React, { useEffect, useState, Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';

const HomePage = lazy(() => import('@/pages/HomePage'));
const QRScannerPage = lazy(() => import('@/pages/QRScanner'));
const AdminDashboard = lazy(() => import('@/pages/AdminDashboard'));
const AdminLogin = lazy(() => import('@/pages/AdminLogin'));
const UserDashboard = lazy(() => import('@/pages/UserDashboard'));
const UserProfile = lazy(() => import('@/pages/UserProfile'));

const LoadingFallback = () => (
  <div className="min-h-screen flex items-center justify-center bg-white">
    <div className="text-slate-800 text-xl animate-pulse">Loading Page...</div>
  </div>
);

function App() {
  const [logoUrl, setLogoUrl] = useState('/favicon.png');
  const { toast } = useToast();

  useEffect(() => {
    const fetchLogo = async () => {
      try {
        const { data, error } = await supabase
          .from('site_settings')
          .select('setting_value')
          .eq('setting_key', 'logo_url')
          .single();

        if (data && data.setting_value) {
          setLogoUrl(data.setting_value);
          
          const link = document.querySelector("link[rel~='icon']");
          if (link) {
            link.href = data.setting_value;
          } else {
            const newLink = document.createElement('link');
            newLink.rel = 'icon';
            newLink.href = data.setting_value;
            document.head.appendChild(newLink);
          }
        } else if (error && error.code !== 'PGRST116') { 
          console.warn("Error fetching logo:", error.message);
          if (error.message.includes('Failed to fetch')) {
            toast({
              title: "Network Error",
              description: "Could not connect to fetch site settings. The default logo will be used.",
              variant: "destructive"
            });
          }
        }
      } catch (e) {
        console.warn("Exception fetching logo:", e.message);
        toast({
          title: "Application Error",
          description: "An unexpected error occurred while fetching the site logo.",
          variant: "destructive"
        });
      }
    };
    fetchLogo();

    const handleLogoUpdate = (event) => {
      const newUrl = event.detail.logoUrl + `?t=${new Date().getTime()}`;
      setLogoUrl(newUrl);
      const link = document.querySelector("link[rel~='icon']");
      if (link) {
        link.href = newUrl;
      }
    };
    window.addEventListener('logoUpdated', handleLogoUpdate);
    return () => window.removeEventListener('logoUpdated', handleLogoUpdate);

  }, [toast]);


  return (
    <Router>
      <Suspense fallback={<LoadingFallback />}>
        <Routes>
          <Route path="/" element={<HomePage logoUrl={logoUrl} />} />
          <Route path="/scanner" element={<QRScannerPage />} />
          <Route path="/dashboard/:userId" element={<UserDashboard logoUrl={logoUrl} />} />
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin/dashboard" element={<AdminDashboard logoUrl={logoUrl} />} />
          <Route path="/profile/:userId" element={<UserProfile />} />
        </Routes>
      </Suspense>
      <Toaster />
    </Router>
  );
}

export default App;