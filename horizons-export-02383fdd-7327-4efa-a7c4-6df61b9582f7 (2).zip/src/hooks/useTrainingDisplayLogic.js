import { useCallback } from 'react';
import { CheckCircle, Clock, ListX, XCircle, AlertCircle } from 'lucide-react';
import { normalizeString } from '@/lib/excelHelper';

export const useTrainingDisplayLogic = () => {
  const getStatusColor = useCallback((status) => {
    switch (normalizeString(status)) {
      case 'passed': return 'text-green-400 bg-green-400/10 border border-green-400/30';
      case 'pending': return 'text-yellow-400 bg-yellow-400/10 border border-yellow-400/30';
      case 'in progress': return 'text-blue-400 bg-blue-400/10 border border-blue-400/30';
      case 'n/r':
      case 'not required':
        return 'text-sky-400 bg-sky-400/10 border border-sky-400/30';
      case 'n/a':
        return 'text-gray-400 bg-gray-400/10 border border-gray-400/30';
      default: return 'text-gray-400 bg-gray-400/10 border border-gray-400/30';
    }
  }, []);

  const getStatusIcon = useCallback((status) => {
    switch (normalizeString(status)) {
      case 'passed': return CheckCircle;
      case 'pending': return AlertCircle; 
      case 'in progress': return Clock;
      case 'n/r':
      case 'not required':
        return ListX;
      case 'n/a':
        return XCircle;
      default: return XCircle;
    }
  }, []);

  const getCategoryTag = useCallback((record) => {
    if (record.hsse_category) return record.hsse_category;
    if (record.is_mandatory) return 'M';
    if (record.is_priority) return 'P1';
    if (normalizeString(record.status) === 'n/r' || normalizeString(record.status) === 'not required') return 'N/R';
    if (normalizeString(record.status) === 'n/a') return 'N/A'; 
    return '';
  }, []);

  return { getStatusColor, getStatusIcon, getCategoryTag };
};