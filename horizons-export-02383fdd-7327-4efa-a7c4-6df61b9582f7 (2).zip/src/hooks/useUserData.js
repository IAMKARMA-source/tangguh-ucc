import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';
import { getTrainingModulesForArea } from '@/lib/trainingModules';
import { normalizeString } from '@/lib/excelHelper';
import { deriveTrainingDetails } from '@/lib/trainingDerivations';

export const useUserData = (userId) => {
  const { toast } = useToast();
  const [userData, setUserData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const loadUserData = useCallback(async () => {
    setIsLoading(true);
    setUserData(null);

    if (!userId) {
      toast({ title: "Error: No User ID", description: "User ID is missing from the URL.", variant: "destructive", duration: 5000 });
      setIsLoading(false);
      return;
    }

    try {
      const { data: employeeData, error: employeeError } = await supabase
        .from('employees')
        .select('*, training_records(*), employee_images(*)')
        .eq('id', userId)
        .single();

      if (employeeError) {
        if (employeeError.code === 'PGRST116') {
          toast({ title: "Employee Not Found", description: "No employee profile matches this ID.", variant: "destructive", duration: 5000 });
        } else {
          toast({ title: "Database Error", description: `Could not load employee data: ${employeeError.message}`, variant: "destructive", duration: 5000 });
        }
        setIsLoading(false);
        return;
      }

      if (!employeeData) {
        toast({ title: "Employee Data Missing", description: "No data was returned for this employee ID.", variant: "destructive", duration: 5000 });
        setIsLoading(false);
        return;
      }

      if (!employeeData.approved) {
        toast({ title: "Profile Pending Approval", description: "This employee's profile is awaiting administrator approval.", variant: "default", duration: 7000 });
        setUserData({ ...employeeData, isPending: true });
        setIsLoading(false);
        return;
      }

      const isOffshore = employeeData.designated_area && normalizeString(employeeData.designated_area) === 'offshore';
      const userTrainingModules = getTrainingModulesForArea(isOffshore);

      let positionMatrixRules = { mandatory_trainings: [], priority_trainings: [], not_required_trainings: [] };
      
      if (employeeData.position) {
        const matrixTable = isOffshore ? 'position_training_matrix_offshore' : 'position_training_matrix';
        
        const { data: allMatrixRows, error: matrixError } = await supabase
          .from(matrixTable)
          .select('Job_Role_Title, mandatory_trainings, priority_trainings, not_required_trainings');

        if (matrixError) {
          console.error(`Error fetching position matrix from ${matrixTable}:`, matrixError.message);
        } else if (allMatrixRows) {
          const employeePositionNormalized = normalizeString(employeeData.position);
          const matrixRow = allMatrixRows.find(row => 
            row.Job_Role_Title && normalizeString(row.Job_Role_Title) === employeePositionNormalized
          );
          
          if (matrixRow) {
            positionMatrixRules = {
              mandatory_trainings: matrixRow.mandatory_trainings || [],
              priority_trainings: matrixRow.priority_trainings || [],
              not_required_trainings: matrixRow.not_required_trainings || [],
            };
          }
        }
      }
      
      const finalRecords = userTrainingModules.map(moduleName => {
        const existingRecord = employeeData.training_records.find(r => normalizeString(r.module) === normalizeString(moduleName));
        
        const { 
          finalStatus, 
          formattedDate, 
          progress, 
          isMandatory, 
          isPriority, 
          derivedHsseCategory 
        } = deriveTrainingDetails(moduleName, positionMatrixRules, existingRecord?.status, existingRecord?.date, isOffshore);
        
        return {
          module: moduleName,
          status: finalStatus,
          date: formattedDate,
          progress: progress,
          training_code: existingRecord?.training_code || null,
          is_mandatory: isMandatory,
          is_priority: isPriority,
          hsse_category: derivedHsseCategory, 
          ...(existingRecord || {}), 
          id: existingRecord?.id, 
          employee_id: employeeData.id 
        };
      });

      setUserData({ ...employeeData, training_records: finalRecords });

    } catch (err) {
      console.error("Unexpected error in loadUserData:", err);
      toast({ title: "Application Error", description: `An unexpected error occurred: ${err.message}`, variant: "destructive", duration: 5000 });
    } finally {
      setIsLoading(false);
    }
  }, [userId, toast]);

  useEffect(() => {
    loadUserData();
  }, [loadUserData]);

  return { userData, isLoading, loadUserData };
};