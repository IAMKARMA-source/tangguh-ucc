import { useMemo } from 'react';
import { normalizeString } from '@/lib/excelHelper';
import { getTotalTrainingModulesForArea, getTrainingModulesForArea } from '@/lib/trainingModules';

const inhouseTrainingModuleNames = [
  'Strong HSE (Only HSE personnel)', 
  'Human Performance',
  'Leadership in Health and Safety Phase #1',
  'Leadership in Health and Safety Phase #2 (cascade)',
  'Leadership in Health and Safety Phase #3 (Supv.)',
  'Work at Height (theory and practical)', 
  'Confined Space Entry (theory and practical)',
  'Commissioning HSE Awareness', 
  'Control of Work',
  'Biodiversity Conservation (enviro)',
  'Waste Management (enviro)',
  'Spill Response (enviro)', 
  'Malaria Control (Health)',
  'Basic Food Safety',
  'Control of Substance Hazardous to Health (Industrial)',
  'Black Id',
  'Process Safety Fundamental'
].map(normalizeString);

const thirdPartyTrainingModuleNames = [
  'Commercial Diver Certification',
  'Basic Offshore Safety Induction and Emergency Training (BOSIET)',
  'Further Offshore Emergency Training (FOET)',
  'Authorized Gas Testing',
  'First Aider Level 2',
  'First Aid Level 3',
  'Kemenaker K3 Kebakaran (Kelas B)',
  'Kemenaker K3 Kebakaran (Kelas D)',
  'Confined Space Rescue',
  'Defensive Driving Training',
  'HACCP',
  'IMO Level 1',
  'IMO Level 2',
  'Security Basic  (Gada Pratama)',
  'Advanced Security (Gada Madya)',
  'Managerial Security (Gada Utama)'
].map(normalizeString);

export const useTrainingCalculations = (userTrainingRecords, userData = null) => {
  const isOffshore = userData?.designated_area && normalizeString(userData.designated_area) === 'offshore';
  const totalTrainingModules = getTotalTrainingModulesForArea(isOffshore);
  const allTrainingModules = getTrainingModulesForArea(isOffshore);

  const completedModulesCount = useMemo(() => {
    if (!userTrainingRecords) return 0;
    return userTrainingRecords.filter(r => normalizeString(r.status) === 'passed').length;
  }, [userTrainingRecords]);

  const overallProgressPercent = useMemo(() => {
    return totalTrainingModules > 0 ? Math.round((completedModulesCount / totalTrainingModules) * 100) : 0;
  }, [completedModulesCount, totalTrainingModules]);

  const mandatoryTrainingsList = useMemo(() => {
    if (!userTrainingRecords) return [];
    return userTrainingRecords
      .filter(m => m.is_mandatory === true)
      .map(m => {
        const statusNormalized = normalizeString(m.status);
        return {
          ...m,
          status: statusNormalized === 'passed' ? 'Passed' : 'Pending',
        };
      });
  }, [userTrainingRecords]);
  
  const createTrainingList = (moduleNames, userRecords, allModulesForArea) => {
    if (!userRecords) return [];
    const listRecords = [];
    const userRecordMap = new Map(userRecords.map(record => [normalizeString(record.module), record]));

    const availableModules = moduleNames.filter(normalizedName => 
      allModulesForArea.some(module => normalizeString(module) === normalizedName)
    );

    availableModules.forEach(normalizedModuleName => {
      const originalModuleName = allModulesForArea.find(m => normalizeString(m) === normalizedModuleName) || normalizedModuleName;
      const existingRecord = userRecordMap.get(normalizedModuleName);

      if (existingRecord) {
        listRecords.push({ ...existingRecord, module: originalModuleName });
      } else {
        listRecords.push({
          module: originalModuleName,
          status: 'Pending',
          date: null,
          progress: 0,
          training_code: null,
          is_mandatory: false, 
          is_priority: false,
          hsse_category: 'N/R', 
        });
      }
    });
    return listRecords;
  };

  const inhouseTrainingsList = useMemo(() => {
    return createTrainingList(inhouseTrainingModuleNames, userTrainingRecords, allTrainingModules);
  }, [userTrainingRecords, allTrainingModules]);
  
  const thirdPartyTrainingsList = useMemo(() => {
    return createTrainingList(thirdPartyTrainingModuleNames, userTrainingRecords, allTrainingModules);
  }, [userTrainingRecords, allTrainingModules]);


  return {
    completedModulesCount,
    overallProgressPercent,
    mandatoryTrainingsList,
    inhouseTrainingsList,
    thirdPartyTrainingsList
  };
};