import React from 'react';
import { motion } from 'framer-motion';
import { Briefcase, AlertTriangle, ShieldCheck, Info, Users } from 'lucide-react';

const ComplianceCircle = ({ percentage }) => {
  const sqSize = 50;
  const strokeWidth = 5;
  const radius = (sqSize - strokeWidth) / 2;
  const viewBox = `0 0 ${sqSize} ${sqSize}`;
  const dashArray = radius * Math.PI * 2;
  const dashOffset = dashArray - (dashArray * percentage) / 100;

  return (
    <svg width={sqSize} height={sqSize} viewBox={viewBox} className="transform -rotate-90">
      <circle className="text-slate-700" cx={sqSize / 2} cy={sqSize / 2} r={radius} strokeWidth={`${strokeWidth}px`} fill="none" stroke="currentColor" />
      <circle
        className="text-green-400 transition-all duration-1000 ease-in-out"
        cx={sqSize / 2} cy={sqSize / 2} r={radius} strokeWidth={`${strokeWidth}px`} fill="none"
        stroke="currentColor" strokeLinecap="round" strokeDasharray={dashArray} strokeDashoffset={dashOffset}
      />
      <text
        className="fill-current text-white font-bold text-xs" x="50%" y="50%" dy=".3em"
        textAnchor="middle" transform={`rotate(90 ${sqSize/2} ${sqSize/2})`}
      >
        {`${percentage}%`}
      </text>
    </svg>
  );
};

const AdminOverview = ({ isLoading, positionStats }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }} 
      animate={{ opacity: 1, y: 0 }} 
      transition={{ duration: 0.5, delay: 0.2 }} 
      className="bg-slate-800/50 border border-slate-700 rounded-xl p-6 mb-8 shadow-lg"
    >
      <h2 className="text-xl font-bold text-white mb-4">Position Compliance Overview</h2>
      {isLoading ? (
        <div className="text-center py-8 text-slate-400">Loading position stats...</div>
      ) : Object.keys(positionStats).length === 0 ? (
         <div className="text-center py-8 text-slate-400">No position data available. Upload an Excel file with 'Matrix' and 'Database' sheets.</div>
      ) : (
        <div className="flex overflow-x-auto space-x-4 pb-4 custom-scrollbar">
          {Object.entries(positionStats).map(([position, data]) => {
            const compliancePercentage = data.total > 0 ? Math.round((data.completedMandatory / data.total) * 100) : 0;
            return (
              <motion.div 
                key={position} 
                className="flex-shrink-0 w-64 bg-slate-800 p-4 rounded-lg border border-slate-700 hover:border-sky-500/50 transition-colors"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3 }}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-md font-semibold text-sky-300 flex items-center mb-2 truncate" title={position}>
                      <Briefcase className="h-4 w-4 mr-2 flex-shrink-0"/> 
                      <span className="truncate">{position}</span>
                    </h3>
                    <div className="flex items-center text-xs text-slate-400">
                      <Users className="h-3 w-3 mr-1.5"/> {data.total} Employee(s)
                    </div>
                  </div>
                  <ComplianceCircle percentage={compliancePercentage} />
                </div>
                <div className="text-xs space-y-1.5 text-slate-300 mt-3">
                  <p className="flex items-center justify-between">
                    <span className="flex items-center"><ShieldCheck className="h-3.5 w-3.5 mr-1.5 text-green-400"/> Mandatory Complete:</span>
                    <span className="font-semibold text-green-400">{data.completedMandatory}</span>
                  </p>
                  <p className="flex items-center justify-between">
                    <span className="flex items-center"><AlertTriangle className="h-3.5 w-3.5 mr-1.5 text-yellow-400"/> Mandatory Pending:</span>
                    <span className={`font-semibold ${data.pendingMandatory > 0 ? 'text-yellow-400' : 'text-slate-400'}`}>
                      {data.pendingMandatory}
                    </span>
                  </p>
                </div>
              </motion.div>
            )
          })}
        </div>
      )}
      <div className="mt-4 bg-slate-700/30 border border-slate-600 p-3 rounded-md text-slate-400 text-xs">
        <h4 className="font-semibold text-white mb-1 flex items-center"><Info className="h-4 w-4 mr-2 text-sky-400"/>Definitions:</h4>
        <ul className="space-y-0.5 list-disc list-inside pl-1">
          <li><span className="font-semibold text-red-400">M (Mandatory):</span> Required for all personnel in the position.</li>
          <li><span className="font-semibold text-yellow-400">P1 (Activity Based):</span> Required for specific activities.</li>
          <li><span className="font-semibold text-sky-400">N/R (Not Required):</span> Not required for this position.</li>
        </ul>
      </div>
    </motion.div>
  );
};

export default AdminOverview;