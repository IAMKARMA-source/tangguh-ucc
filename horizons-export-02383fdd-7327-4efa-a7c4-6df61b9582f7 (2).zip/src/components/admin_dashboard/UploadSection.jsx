import React from 'react';
import { motion } from 'framer-motion';
import { UploadCloud } from 'lucide-react';
import { Button } from '@/components/ui/button';

const UploadSection = ({
  title,
  icon: Icon,
  iconColor,
  isUploading,
  onFileChange,
  onUpload,
  selectedFile,
  accept,
  inputId,
  info
}) => {
  const colorClass = iconColor.replace('text-', '');

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }} 
      animate={{ opacity: 1, y: 0 }} 
      transition={{ duration: 0.5 }} 
      className="bg-slate-800/50 border border-slate-700 rounded-xl p-6 shadow-lg"
    >
      <h2 className="text-xl font-bold text-white mb-4 flex items-center">
        <Icon className={`mr-3 ${iconColor} h-6 w-6`}/>{title}
      </h2>
      <div className="grid grid-cols-1 gap-4">
        <div>
          <label 
            htmlFor={inputId} 
            className={`flex flex-col items-center justify-center border-2 border-dashed border-slate-600 rounded-lg p-8 text-center transition-colors ${isUploading ? 'cursor-not-allowed bg-slate-800/50' : `cursor-pointer hover:border-${colorClass}-500 hover:bg-${colorClass}-500/10`}`}
          >
            <input 
              type="file" 
              accept={accept} 
              onChange={onFileChange} 
              className="hidden" 
              id={inputId} 
              disabled={isUploading}
            />
            <UploadCloud className={`h-10 w-10 text-slate-400 mx-auto mb-3 ${isUploading ? 'animate-pulse' : ''}`} />
            <p className="text-white font-semibold mb-1">{isUploading ? `Uploading...` : `Choose File`}</p>
            <p className="text-slate-400 text-sm">{isUploading ? 'Please wait.' : `Select a ${accept.split(',')[0].split('/')[1] || accept.split('.')[1]} file.`}</p>
          </label>
          {selectedFile && (
            <div className="mt-3 text-center text-sm text-slate-300">
              Selected: <span className="font-medium text-white">{selectedFile.name}</span>
            </div>
          )}
          <Button onClick={onUpload} className={`w-full mt-3 bg-${colorClass}-500/80 hover:bg-${colorClass}-500 text-white`} disabled={isUploading || !selectedFile}>
            {isUploading ? 'Uploading...' : `Upload File`}
          </Button>
        </div>
        <div className={`bg-slate-700/30 rounded-md p-3 border-l-4 border-${colorClass}-500`}>
          <h3 className="text-white font-semibold mb-1 text-sm">{info.title}</h3>
          <ul className="text-slate-400 text-xs space-y-0.5">
            {info.list.map((item, index) => (
              <li key={index}>• {item}</li>
            ))}
          </ul>
        </div>
      </div>
    </motion.div>
  );
};

export default UploadSection;