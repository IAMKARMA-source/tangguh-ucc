import React from 'react';
import { motion } from 'framer-motion';
import { LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';

const AdminHeader = ({ logoUrl, onLogout }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: -30 }} 
      animate={{ opacity: 1, y: 0 }} 
      transition={{ duration: 0.6 }} 
      className="flex items-center justify-between mb-8"
    >
      <div className="flex items-center space-x-3">
        {logoUrl && <img src={logoUrl} alt="Site Logo" className="h-10 w-auto rounded-md" onError={(e) => e.target.style.display='none'}/>}
        <h1 className="text-3xl md:text-4xl font-bold text-white">Admin Dashboard</h1>
      </div>
      <Button onClick={onLogout} variant="outline" className="border-red-500 text-red-300 hover:bg-red-500 hover:text-white">
        <LogOut className="mr-2 h-4 w-4" /> Logout
      </Button>
    </motion.div>
  );
};

export default AdminHeader;