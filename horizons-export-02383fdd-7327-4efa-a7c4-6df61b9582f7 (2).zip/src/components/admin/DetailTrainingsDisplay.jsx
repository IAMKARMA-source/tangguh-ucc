import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Layers, Filter, Search, AlertTriangle, CheckSquare, ListChecks, Clock } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const DetailTrainingsDisplay = React.memo(({ matrixData, trainingHeaders }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [classificationFilter, setClassificationFilter] = useState('all');
  
  const uniqueClassifications = useMemo(() => {
    if (!matrixData) return [];
    const classifications = new Set(matrixData.map(item => item.classification).filter(Boolean));
    return ['all', ...Array.from(classifications)];
  }, [matrixData]);

  const filteredData = useMemo(() => {
    if (!matrixData) return [];
    return matrixData.filter(item => {
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch = item.job_role_title.toLowerCase().includes(searchLower) ||
                            (item.classification && item.classification.toLowerCase().includes(searchLower));
      
      const matchesClassification = classificationFilter === 'all' || item.classification === classificationFilter;
      
      return matchesSearch && matchesClassification;
    });
  }, [matrixData, searchTerm, classificationFilter]);

  const getStatusBadge = (status) => {
    const s = String(status).toUpperCase();
    if (s === 'M') return <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-red-500/20 text-red-300 border border-red-500/50">M</span>;
    if (s === 'P1') return <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-yellow-500/20 text-yellow-300 border border-yellow-500/50">P1</span>;
    if (s === 'N/R') return <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-sky-500/20 text-sky-300 border border-sky-500/50">N/R</span>;
    if (s === 'PASSED' || s === 'COMPLETED' ) return <CheckSquare className="h-4 w-4 text-green-400" />;
    if (s === 'PENDING' || s === 'IN PROGRESS') return <Clock className="h-4 w-4 text-yellow-400" />;
    return <span className="text-xs text-slate-400">{status}</span>;
  };
  

  if (!matrixData || matrixData.length === 0) {
    return (
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        className="bg-slate-800/50 border border-slate-700 rounded-xl p-6 my-8 shadow-lg text-center text-slate-400"
      >
        <Layers className="h-12 w-12 mx-auto mb-4 text-slate-500" />
        <h3 className="text-lg font-semibold text-white mb-1">No HSSE Matrix Data to Display</h3>
        <p className="text-sm">Upload or process a file above to view the training matrix.</p>
      </motion.div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }} 
      animate={{ opacity: 1, y: 0 }} 
      className="bg-slate-800/50 border border-slate-700 rounded-xl p-6 my-8 shadow-lg"
    >
      <h2 className="text-xl font-bold text-white mb-4 flex items-center">
        <ListChecks className="mr-3 text-sky-400 h-6 w-6"/>HSSE Training Matrix Details
      </h2>
      
      <div className="flex flex-col sm:flex-row gap-4 mb-4">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input 
            type="text"
            placeholder="Search by Job Role or Classification..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9 bg-slate-800 border-slate-700 text-white focus:border-sky-500"
          />
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700 hover:text-white min-w-[200px]">
              <Filter className="mr-2 h-4 w-4" /> 
              Classification: {classificationFilter === 'all' ? 'All' : classificationFilter}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56 bg-slate-800 border-slate-700 text-white">
            {uniqueClassifications.map(cls => (
              <DropdownMenuCheckboxItem
                key={cls}
                checked={classificationFilter === cls}
                onCheckedChange={() => setClassificationFilter(cls)}
                className="hover:bg-sky-500/20 focus:bg-sky-500/30 cursor-pointer"
              >
                {cls === 'all' ? 'All Classifications' : cls}
              </DropdownMenuCheckboxItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {filteredData.length === 0 && (
        <div className="text-center py-10 text-slate-400">
          <AlertTriangle className="h-10 w-10 mx-auto mb-3 text-yellow-500" />
          No positions match your current filters.
        </div>
      )}

      {filteredData.length > 0 && (
        <div className="overflow-x-auto custom-scrollbar max-h-[70vh]">
          <table className="w-full min-w-[1000px] text-sm">
            <thead>
              <tr className="border-b border-slate-700">
                <th className="sticky left-0 bg-slate-800/80 backdrop-blur-sm p-3 text-left text-slate-400 font-semibold z-10">Job Role Title</th>
                <th className="p-3 text-left text-slate-400 font-semibold">Classification</th>
                {trainingHeaders.map(header => (
                  <th key={header} className="p-3 text-center text-slate-400 font-semibold whitespace-nowrap min-w-[100px] max-w-[150px] truncate" title={header}>{header}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredData.map((item, rowIndex) => (
                <motion.tr 
                  key={item.job_role_title + rowIndex} 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: rowIndex * 0.02 }}
                  className="border-b border-slate-800 hover:bg-slate-700/50"
                >
                  <td className="sticky left-0 bg-slate-800/80 backdrop-blur-sm p-3 text-white font-medium z-10">{item.job_role_title}</td>
                  <td className="p-3 text-slate-300">{item.classification || 'N/A'}</td>
                  {trainingHeaders.map(header => (
                    <td key={header} className="p-3 text-center text-slate-300">
                      {getStatusBadge(item[header])}
                    </td>
                  ))}
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </motion.div>
  );
});
DetailTrainingsDisplay.displayName = 'DetailTrainingsDisplay';

export default DetailTrainingsDisplay;