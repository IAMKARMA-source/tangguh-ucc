import React, { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Settings, Upload } from 'lucide-react';
import { supabase } from '@/lib/supabase';

const SiteSettings = React.memo(({ currentLogoUrl, setCurrentLogoUrl, toast }) => {
  const [isUploadingLogo, setIsUploadingLogo] = useState(false);

  const handleLogoUpload = useCallback(async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setIsUploadingLogo(true);
    const fileExt = file.name.split('.').pop();
    const fileName = `logo.${fileExt}`;
    const filePath = `site_assets/${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from('employee_uploads') 
      .upload(filePath, file, { upsert: true });

    if (uploadError) {
      toast({ title: "Logo Upload Error", description: uploadError.message, variant: "destructive" });
      setIsUploadingLogo(false);
      return;
    }

    const { data: { publicUrl } } = supabase.storage.from('employee_uploads').getPublicUrl(filePath);
    
    const { error: dbError } = await supabase
      .from('site_settings')
      .update({ setting_value: publicUrl })
      .eq('setting_key', 'logo_url');

    if (dbError) {
      toast({ title: "Database Error", description: dbError.message, variant: "destructive" });
    } else {
      toast({ title: "Success", description: "Logo updated successfully!" });
      const newLogoUrl = publicUrl + `?t=${new Date().getTime()}`;
      setCurrentLogoUrl(newLogoUrl); 
      window.dispatchEvent(new CustomEvent('logoUpdated', { detail: { logoUrl: newLogoUrl } }));
    }
    setIsUploadingLogo(false);
    if (event.target) event.target.value = '';
  }, [setCurrentLogoUrl, toast]);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }} 
      animate={{ opacity: 1, y: 0 }} 
      transition={{ duration: 0.5 }} 
      className="bg-slate-800/50 border border-slate-700 rounded-xl p-6 shadow-lg"
    >
      <h2 className="text-xl font-bold text-white mb-4 flex items-center">
        <Settings className="mr-3 text-slate-400 h-6 w-6"/>Site Settings
      </h2>
      <div>
        <label className="block mb-2 text-slate-300 text-sm">Website Logo</label>
        <div className="flex items-center space-x-4">
          {currentLogoUrl && <img src={currentLogoUrl} alt="Current Logo" className="h-16 w-16 rounded-md object-contain bg-slate-700/50 p-1" onError={(e) => e.target.style.display='none'}/>}
          <input type="file" accept="image/png, image/jpeg, image/svg+xml" onChange={handleLogoUpload} className="hidden" id="logo-upload-input" disabled={isUploadingLogo} />
          <label htmlFor="logo-upload-input" className={`border-2 border-dashed border-slate-600 rounded-lg p-4 text-center transition-colors flex-grow ${isUploadingLogo ? 'cursor-not-allowed bg-slate-800/50' : 'cursor-pointer hover:border-green-500 hover:bg-green-500/10'}`}>
            <Upload className={`h-8 w-8 text-slate-400 mx-auto mb-2 ${isUploadingLogo ? 'animate-pulse' : ''}`} />
            <p className="text-white font-semibold text-sm">{isUploadingLogo ? 'Uploading...' : 'Choose New Logo'}</p>
          </label>
        </div>
        <p className="text-xs text-slate-400 mt-2">Recommended: square, .png format. Updates site logo and favicon.</p>
      </div>
    </motion.div>
  );
});
SiteSettings.displayName = 'SiteSettings';

export default SiteSettings;