import React from 'react';
import { motion } from 'framer-motion';
import { Users, CheckCircle, Clock, UserCheck } from 'lucide-react';

const StatCard = React.memo(({ title, value, icon: Icon, color, delay }) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }} 
    animate={{ opacity: 1, y: 0 }} 
    transition={{ duration: 0.5, delay }}
    className="bg-slate-800/50 border border-slate-700 rounded-xl p-5 shadow-lg hover:border-slate-600 transition-colors"
  >
    <div className="flex items-center justify-between">
      <div>
        <p className="text-slate-400 text-sm font-medium">{title}</p>
        <p className={`text-3xl font-bold ${color}`}>{value}</p>
      </div>
      <div className={`p-3 rounded-full bg-slate-700/50`}>
        <Icon className={`h-6 w-6 ${color}`} />
      </div>
    </div>
  </motion.div>
));
StatCard.displayName = 'StatCard';

const AdminStats = React.memo(({ stats }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <StatCard title="Total Users" value={stats.totalUsers} icon={Users} color="text-sky-400" delay={0} />
      <StatCard title="Approved" value={stats.approvedUsers} icon={CheckCircle} color="text-green-400" delay={0.1} />
      <StatCard title="Pending" value={stats.pendingUsers} icon={Clock} color="text-yellow-400" delay={0.2} />
      <StatCard title="Fully Completed" value={stats.fullyCompletedUsers} icon={UserCheck} color="text-emerald-400" delay={0.3} />
    </div>
  );
});
AdminStats.displayName = 'AdminStats';

export default AdminStats;