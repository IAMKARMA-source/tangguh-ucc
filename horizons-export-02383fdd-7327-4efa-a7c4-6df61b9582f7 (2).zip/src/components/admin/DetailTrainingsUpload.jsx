import React, { useState, useCallback, useEffect } from 'react';
import { motion } from 'framer-motion';
import { UploadCloud, FileText, Trash2, Download, AlertTriangle, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';
import * as XLSX from 'xlsx';
import { normalizeString } from '@/lib/excelHelper';

const DetailTrainingsUpload = React.memo(({ onMatrixDataProcessed }) => {
  const { toast } = useToast();
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const [filesToUpload, setFilesToUpload] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const fetchUploadedFiles = useCallback(async () => {
    const { data, error } = await supabase
      .from('training_detail_files')
      .select('*')
      .order('uploaded_at', { ascending: false });

    if (error) {
      toast({ title: "Error fetching files", description: error.message, variant: "destructive" });
    } else {
      setUploadedFiles(data || []);
    }
  }, [toast]);

  useEffect(() => {
    fetchUploadedFiles();
  }, [fetchUploadedFiles]);

  const handleFileChange = (event) => {
    const selectedFiles = Array.from(event.target.files);
    if (selectedFiles.length === 0) return;

    if (filesToUpload.length + selectedFiles.length > 2) {
      toast({ title: "File Limit Exceeded", description: "You can select a maximum of 2 files.", variant: "destructive" });
      return;
    }
    setFilesToUpload(prevFiles => {
      const newFiles = selectedFiles.filter(sf => !prevFiles.some(pf => pf.name === sf.name));
      return [...prevFiles, ...newFiles].slice(0, 2);
    });
    if (event.target) event.target.value = null; 
  };

  const removeFileToUpload = (fileName) => {
    setFilesToUpload(prevFiles => prevFiles.filter(file => file.name !== fileName));
  };

  const processAndStoreMatrix = async (fileObject, fileRecordId) => {
    setIsProcessing(true);
    try {
      const arrayBuffer = await fileObject.arrayBuffer();
      const workbook = XLSX.read(arrayBuffer, { type: 'buffer' });
      
      const sheetName = workbook.SheetNames.find(name => normalizeString(name).includes('matrix'));
      if (!sheetName) {
        throw new Error("HSSE Training Matrix sheet not found. Ensure a sheet name contains 'matrix'.");
      }
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

      if (jsonData.length < 2) {
        throw new Error("Excel file's matrix sheet seems empty or has no header row.");
      }
      
      const rawHeaders = jsonData[0];
      const headers = rawHeaders.map(header => normalizeString(String(header || '')));
      
      const jobRoleTitleIndex = headers.indexOf('job role title');
      const classificationIndex = headers.indexOf('classification');
      
      if (jobRoleTitleIndex === -1) {
        throw new Error("Column 'Job Role Title' not found in the Excel sheet.");
      }

      const matrixEntries = [];
      const processedDataForFile = [];

      for (let i = 1; i < jsonData.length; i++) {
        const row = jsonData[i];
        const jobRoleTitle = row[jobRoleTitleIndex];
        if (!jobRoleTitle) continue;

        const classification = classificationIndex !== -1 ? row[classificationIndex] : null;
        const trainingData = {};
        
        rawHeaders.forEach((header, index) => {
          if (index !== jobRoleTitleIndex && index !== classificationIndex) {
            const trainingName = String(header || ''); 
            const statusOrDuration = row[index];
            if (trainingName && statusOrDuration !== undefined && statusOrDuration !== null) {
              trainingData[trainingName] = String(statusOrDuration);
            }
          }
        });
        
        matrixEntries.push({
          job_role_title: String(jobRoleTitle),
          classification: classification ? String(classification) : null,
          training_data: trainingData,
          file_id: fileRecordId
        });
        processedDataForFile.push({ job_role_title: String(jobRoleTitle), classification: classification ? String(classification) : null, ...trainingData });
      }

      if (matrixEntries.length > 0) {
        const { error: deleteError } = await supabase
          .from('hsse_training_matrix')
          .delete()
          .neq('id', '00000000-0000-0000-0000-000000000000'); 
        if (deleteError) throw new Error(`Failed to clear old HSSE matrix data: ${deleteError.message}`);
        
        const { error: insertError } = await supabase
          .from('hsse_training_matrix')
          .insert(matrixEntries);
        if (insertError) throw new Error(`Failed to insert HSSE matrix data: ${insertError.message}`);
      }
      
      const { error: updateFileError } = await supabase
        .from('training_detail_files')
        .update({ processed_data: processedDataForFile })
        .eq('id', fileRecordId);
      if (updateFileError) console.warn("Could not update file with processed HSSE data:", updateFileError.message);


      toast({ title: "HSSE Matrix Processed", description: `Successfully extracted ${matrixEntries.length} HSSE matrix entries from ${fileObject.name}.`});
      if (onMatrixDataProcessed) {
        const displayHeaders = rawHeaders.filter((h,idx) => idx !== jobRoleTitleIndex && idx !== classificationIndex);
        onMatrixDataProcessed(processedDataForFile, displayHeaders);
      }

    } catch (error) {
      toast({ title: `Error processing ${fileObject.name}`, description: error.message, variant: "destructive" });
      console.error("Error processing HSSE matrix:", error);
      if (onMatrixDataProcessed) { 
        onMatrixDataProcessed([], []);
      }
    } finally {
      setIsProcessing(false);
    }
  };


  const handleUploadAndProcess = async () => {
    if (filesToUpload.length === 0) {
      toast({ title: "No files selected", description: "Please select files to upload.", variant: "default" });
      return;
    }

    setIsUploading(true);
    let successCount = 0;
    let firstFileToProcess;
    let firstFileRecordId;

    for (const file of filesToUpload) {
      const fileName = `${Date.now()}-${file.name}`;
      const filePath = `training_details/${fileName}`;

      try {
        const { error: uploadError } = await supabase.storage
          .from('employee_uploads') 
          .upload(filePath, file, { upsert: true });

        if (uploadError) throw uploadError;

        const { data: publicUrlData } = supabase.storage.from('employee_uploads').getPublicUrl(filePath);
        const publicUrl = publicUrlData.publicUrl;
        
        const { data: insertedFile, error: dbError } = await supabase
          .from('training_detail_files')
          .insert({ file_name: file.name, file_url: publicUrl, file_type: file.type || 'application/octet-stream' })
          .select()
          .single();

        if (dbError) throw dbError;

        if (!firstFileToProcess) {
          firstFileToProcess = file;
          firstFileRecordId = insertedFile.id;
        }
        successCount++;
      } catch (error) {
        toast({ title: `Error uploading ${file.name}`, description: error.message, variant: "destructive" });
      }
    }

    setIsUploading(false);
    setFilesToUpload([]);
    if (successCount > 0) {
      toast({ title: "Upload Complete", description: `${successCount} file(s) uploaded successfully.` });
      fetchUploadedFiles();
      if (firstFileToProcess && firstFileRecordId) {
        await processAndStoreMatrix(firstFileToProcess, firstFileRecordId);
      }
    }
  };

  const handleDeleteFile = async (fileId, fileUrl) => {
    try {
      const filePath = fileUrl.substring(fileUrl.indexOf('training_details/'));
      const { error: storageError } = await supabase.storage.from('employee_uploads').remove([filePath]);
      if (storageError && storageError.message !== 'The resource was not found') {
         console.warn("Supabase storage delete error (might be ignorable if file already removed):", storageError.message);
      }

      await supabase.from('hsse_training_matrix').delete().eq('file_id', fileId);
      const { error: dbError } = await supabase.from('training_detail_files').delete().eq('id', fileId);
      if (dbError) throw dbError;

      toast({ title: "File Deleted", description: "The file and its matrix data have been removed." });
      fetchUploadedFiles();
      if (onMatrixDataProcessed) onMatrixDataProcessed([], []); 
    } catch (error) {
      toast({ title: "Error deleting file", description: error.message, variant: "destructive" });
    }
  };
  
  const handleViewAndProcessExistingFile = async (file) => {
    if (file.processed_data && Array.isArray(file.processed_data) && file.processed_data.length > 0) {
        let trainingHeaders = [];
        if (file.processed_data[0]) {
            trainingHeaders = Object.keys(file.processed_data[0]).filter(key => key !== 'job_role_title' && key !== 'classification');
        }
        if (onMatrixDataProcessed) onMatrixDataProcessed(file.processed_data, trainingHeaders);
        toast({ title: "Matrix Loaded", description: `Displaying cached matrix data for ${file.file_name}.` });
    } else {
        try {
            setIsProcessing(true);
            const response = await fetch(file.file_url);
            if (!response.ok) throw new Error(`Failed to fetch file: ${response.statusText}`);
            const blob = await response.blob();
            const fileObject = new File([blob], file.file_name, { type: file.file_type || 'application/octet-stream' });
            await processAndStoreMatrix(fileObject, file.id);
        } catch (error) {
            toast({ title: `Error processing ${file.file_name}`, description: error.message, variant: "destructive" });
            if (onMatrixDataProcessed) onMatrixDataProcessed([], []);
        } finally {
            setIsProcessing(false);
        }
    }
  };


  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }} 
      animate={{ opacity: 1, y: 0 }} 
      transition={{ duration: 0.5 }} 
      className="bg-slate-800/50 border border-slate-700 rounded-xl p-6 mb-8 shadow-lg"
    >
      <h2 className="text-xl font-bold text-white mb-4 flex items-center">
        <UploadCloud className="mr-3 text-emerald-400 h-6 w-6"/>Upload & Process HSSE Training Matrix
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
        <div>
          <label 
            htmlFor="detail-trainings-upload-input" 
            className={`flex flex-col items-center justify-center border-2 border-dashed border-slate-600 rounded-lg p-8 text-center transition-colors h-full ${isUploading || filesToUpload.length >= 2 || isProcessing ? 'cursor-not-allowed bg-slate-800/50' : 'cursor-pointer hover:border-emerald-500 hover:bg-emerald-500/10'}`}
          >
            <input 
              type="file" 
              accept=".xlsx,.xls" 
              onChange={handleFileChange} 
              className="hidden" 
              id="detail-trainings-upload-input" 
              multiple 
              disabled={isUploading || filesToUpload.length >= 2 || isProcessing}
            />
            <UploadCloud className={`h-10 w-10 text-slate-400 mx-auto mb-3 ${(isUploading || isProcessing) ? 'animate-pulse' : ''}`} />
            <p className="text-white font-semibold mb-1">{isUploading ? 'Uploading...' : isProcessing ? 'Processing...' : 'Choose Excel Files (Max 2)'}</p>
            <p className="text-slate-400 text-sm">{(isUploading || isProcessing) ? 'Please wait.' : 'First file will be processed.'}</p>
          </label>
          {filesToUpload.length > 0 && (
            <div className="mt-4 space-y-2">
              {filesToUpload.map(file => (
                <div key={file.name} className="flex items-center justify-between bg-slate-700/50 p-2 rounded-md text-sm">
                  <span className="text-white truncate">{file.name}</span>
                  <Button variant="ghost" size="sm" onClick={() => removeFileToUpload(file.name)} className="text-red-400 hover:text-red-300 p-1 h-auto" disabled={isUploading || isProcessing}>
                    <Trash2 className="h-4 w-4"/>
                  </Button>
                </div>
              ))}
            </div>
          )}
          <Button onClick={handleUploadAndProcess} className="w-full mt-4 bg-emerald-600 hover:bg-emerald-700 text-white" disabled={isUploading || filesToUpload.length === 0 || isProcessing}>
            {isUploading ? 'Uploading...' : isProcessing ? 'Processing...' : `Upload & Process ${filesToUpload.length} File(s)`}
          </Button>
        </div>

        <div>
          <h3 className="text-lg font-semibold text-white mb-3">Uploaded Files</h3>
          {uploadedFiles.length === 0 ? (
            <div className="text-center text-slate-400 py-6 bg-slate-800/30 rounded-lg">
              <FileText className="mx-auto h-8 w-8 mb-2 text-slate-500" />
              No matrix files uploaded.
            </div>
          ) : (
            <div className="space-y-2 max-h-64 overflow-y-auto pr-2 custom-scrollbar">
              {uploadedFiles.map(file => (
                <div key={file.id} className="flex items-center justify-between bg-slate-800/50 p-2 rounded-lg border border-slate-700">
                  <div className="flex items-center overflow-hidden">
                    <FileText className="h-4 w-4 mr-2 text-sky-400 flex-shrink-0" />
                    <span className="text-white text-sm hover:text-sky-300 transition-colors truncate cursor-pointer" title={`View/Reprocess ${file.file_name}`} onClick={() => handleViewAndProcessExistingFile(file)}>
                      {file.file_name}
                    </span>
                  </div>
                  <div className="flex items-center flex-shrink-0">
                     <Button variant="ghost" size="icon" onClick={() => handleViewAndProcessExistingFile(file)} className="text-sky-400 hover:text-sky-300 h-7 w-7" title="View/Reprocess" disabled={isProcessing}>
                      <Zap className="h-4 w-4"/>
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => window.open(file.file_url, '_blank')} className="text-green-400 hover:text-green-300 h-7 w-7" title="Download" disabled={isProcessing}>
                      <Download className="h-4 w-4"/>
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDeleteFile(file.id, file.file_url)} className="text-red-400 hover:text-red-300 h-7 w-7" title="Delete" disabled={isProcessing}>
                      <Trash2 className="h-4 w-4"/>
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
       <div className="mt-6 bg-yellow-900/30 border border-yellow-700 p-3 rounded-md text-yellow-300 text-xs flex items-start">
        <AlertTriangle className="h-4 w-4 mr-2 mt-0.5 flex-shrink-0 text-yellow-400" />
        <div>
          <p>This section handles the HSSE Training Matrix. Uploading a new file will clear and replace all existing HSSE matrix data. Click a file name or the <Zap size={14} className="inline"/> icon to process and display its contents below.</p>
        </div>
      </div>
    </motion.div>
  );
});
DetailTrainingsUpload.displayName = 'DetailTrainingsUpload';

export default DetailTrainingsUpload;