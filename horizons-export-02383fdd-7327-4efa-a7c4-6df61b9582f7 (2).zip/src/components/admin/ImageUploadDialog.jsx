import React from 'react';
import { Upload } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

const ImageUploadDialog = React.memo(({ selectedUserForImage, setSelectedUserForImage, handleAdminImageUpload }) => {
  if (!selectedUserForImage) return null;

  return (
    <Dialog open={!!selectedUserForImage} onOpenChange={(isOpen) => !isOpen && setSelectedUserForImage(null)}>
      <DialogContent className="sm:max-w-[425px] bg-slate-800 border-slate-700 text-white">
        <DialogHeader>
          <DialogTitle>Upload Image for {selectedUserForImage.name}</DialogTitle>
        </DialogHeader>
        <div className="p-4">
          <label className="block">
            <input type="file" accept="image/*" onChange={handleAdminImageUpload} className="hidden" id="admin-image-upload" />
            <label htmlFor="admin-image-upload" className="border-2 border-dashed border-slate-600 rounded-lg p-8 text-center cursor-pointer hover:border-green-500 hover:bg-green-500/10 transition-colors">
              <Upload className="h-10 w-10 text-slate-400 mx-auto mb-3" />
              <p className="text-white font-semibold mb-1">Upload Image</p>
              <p className="text-slate-400 text-sm">Click to select an image file</p>
            </label>
          </label>
        </div>
      </DialogContent>
    </Dialog>
  );
});
ImageUploadDialog.displayName = 'ImageUploadDialog';

export default ImageUploadDialog;