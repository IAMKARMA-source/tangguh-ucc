import React from 'react';
import { motion } from 'framer-motion';
import { Upload, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { getTrainingModulesForArea } from '@/lib/trainingModules';
import { normalizeString } from '@/lib/excelHelper';

const EmployeeUpload = React.memo(({ onFileUpload, isUploading, users }) => {
  const downloadUserData = React.useCallback(() => {
    const dataToExport = users.map(user => {
      const isOffshore = user.designated_area && normalizeString(user.designated_area) === 'offshore';
      const userTrainingModules = getTrainingModulesForArea(isOffshore);
      
      const employeeData = {
        'No Urut': user.no_urut || '',
        'Name': user.name || '',
        'Id Badge': user.id_badge || '',
        'Position': user.position || '',
        'Company': user.company || '',
        'Designated Area': user.designated_area || 'Onshore',
      };
      
      userTrainingModules.forEach(moduleName => {
        const record = user.training_records?.find(r => normalizeString(r.module) === normalizeString(moduleName));
        if (record) {
          const statusPart = record.status || 'Pending';
          const datePart = record.date || '';
          const codePart = record.training_code || '';
          employeeData[moduleName] = `${statusPart}|${datePart}|${codePart}`;
        } else {
          employeeData[moduleName] = 'Pending||';
        }
      });
      return employeeData;
    });

    const ws = XLSX.utils.json_to_sheet(dataToExport);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Database');
    XLSX.writeFile(wb, 'employee_data_update.xlsx');
  }, [users]);

  const downloadUserDataAsPDF = React.useCallback(() => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text("Employee Database", 14, 22);
    doc.setFontSize(11);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 14, 30);

    const tableColumn = ["No.", "Name", "Id Badge", "Position", "Company", "Area"];
    const tableRows = [];

    const sortedUsers = [...users].sort((a, b) => {
        const aNum = parseInt(a.no_urut) || 0;
        const bNum = parseInt(b.no_urut) || 0;
        return aNum - bNum;
    });

    sortedUsers.forEach((user, index) => {
      const userData = [
        index + 1,
        user.name || '',
        user.id_badge || '',
        user.position || '',
        user.company || '',
        user.designated_area || 'Onshore'
      ];
      tableRows.push(userData);
    });

    doc.autoTable({
      head: [tableColumn],
      body: tableRows,
      startY: 35,
      theme: 'striped',
      headStyles: { fillColor: [30, 41, 59] },
    });

    doc.save('employee_database.pdf');
  }, [users]);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }} 
      animate={{ opacity: 1, y: 0 }} 
      transition={{ duration: 0.5, delay: 0.1 }} 
      className="bg-slate-800/50 border border-slate-700 rounded-xl p-6 mb-8 shadow-lg"
    >
      <h2 className="text-xl font-bold text-white mb-4">Employee Data Management</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
        <div className="flex flex-col justify-center">
          <input type="file" accept=".csv,.xlsx,.xls" onChange={onFileUpload} className="hidden" id="employee-data-upload" disabled={isUploading} />
          <label 
            htmlFor="employee-data-upload" 
            className={`flex flex-col items-center justify-center border-2 border-dashed border-slate-600 rounded-lg p-8 text-center transition-colors h-full ${isUploading ? 'cursor-not-allowed bg-slate-800/50' : 'cursor-pointer hover:border-green-500 hover:bg-green-500/10'}`}
          >
            <Upload className={`h-10 w-10 text-slate-400 mx-auto mb-3 ${isUploading ? 'animate-pulse' : 'group-hover:text-green-400'}`} />
            <p className="text-white font-semibold mb-1">{isUploading ? 'Processing File...' : 'Upload Employee Data'}</p>
            <p className="text-slate-400 text-sm">{isUploading ? 'Please wait.' : 'Sheet name must be "Database"'}</p>
          </label>
        </div>
        <div className="flex flex-col space-y-3">
            <p className="text-slate-400 text-sm">Download the current employee database for reference or bulk updates. Uploading a file will update existing records and add new ones based on ID Badge.</p>
            <Button onClick={downloadUserData} variant="outline" className="w-full border-green-500/50 text-green-400 hover:bg-green-500/20 hover:text-green-300" disabled={users.length === 0}>
              <Download className="mr-2 h-4 w-4" /> Download as Excel
            </Button>
            <Button onClick={downloadUserDataAsPDF} variant="outline" className="w-full border-sky-500/50 text-sky-400 hover:bg-sky-500/20 hover:text-sky-300" disabled={users.length === 0}>
              <Download className="mr-2 h-4 w-4" /> Download as PDF
            </Button>
        </div>
      </div>
    </motion.div>
  );
});
EmployeeUpload.displayName = 'EmployeeUpload';

export default EmployeeUpload;