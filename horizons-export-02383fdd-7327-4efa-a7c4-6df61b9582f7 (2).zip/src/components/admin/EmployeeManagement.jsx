import React from 'react';
import { motion } from 'framer-motion';
import { FileSpreadsheet, RefreshCw, CheckCircle, FileImage as ImageIcon, QrCode, Eye, Trash2, LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import QRCode from 'qrcode.react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { getTotalTrainingModulesForArea } from '@/lib/trainingModules';
import { normalizeString } from '@/lib/excelHelper';

const EmployeeManagement = React.memo(({
  users,
  isLoading,
  loadUsers,
  handleApproval,
  setSelectedUserForImage,
  navigate,
  onDeleteRequest,
  onDeleteAllRequest,
}) => {

  const getUserOverallCompletionStatus = React.useCallback((user) => {
    const isOffshore = user.designated_area && normalizeString(user.designated_area) === 'offshore';
    const totalTrainingModules = getTotalTrainingModulesForArea(isOffshore);
    
    const passedCount = user.training_records?.filter(
      record => record.status?.toLowerCase() === 'passed'
    ).length || 0;

    const percentage = totalTrainingModules > 0 ? Math.round((passedCount / totalTrainingModules) * 100) : 0;

    if (passedCount === totalTrainingModules && totalTrainingModules > 0) {
      return { status: 'Complete', message: `All ${totalTrainingModules} modules passed.`, percentage };
    } else {
      return { status: 'Pending', message: `${passedCount} of ${totalTrainingModules} modules passed.`, percentage };
    }
  }, []);

  const sortedUsers = React.useMemo(() => {
    return [...users].sort((a, b) => {
      const aNum = parseInt(a.no_urut) || 0;
      const bNum = parseInt(b.no_urut) || 0;
      return aNum - bNum;
    });
  }, [users]);

  const handleLoginAsUser = (userId) => {
    const url = `/dashboard/${userId}`;
    window.open(url, '_blank');
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }} 
      animate={{ opacity: 1, y: 0 }} 
      transition={{ duration: 0.5, delay: 0.2 }} 
      className="bg-slate-800/50 border border-slate-700 rounded-xl p-6 shadow-lg"
    >
      <div className="flex flex-col sm:flex-row justify-between items-center mb-4 gap-4">
        <h2 className="text-xl font-bold text-white">Employee Roster</h2>
        <div className="flex items-center gap-2">
          <Button onClick={loadUsers} variant="outline" size="sm" className="border-slate-600 text-slate-300 hover:bg-slate-700 hover:text-white" title="Refresh Data">
            <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
          </Button>
          <Button onClick={onDeleteAllRequest} variant="destructive" size="sm" className="bg-red-600/80 hover:bg-red-600 text-white" title="Delete All User Data" disabled={users.length === 0}>
            <Trash2 className="h-4 w-4 mr-2" /> Delete All Data
          </Button>
        </div>
      </div>
      {isLoading ? (
        <div className="text-center py-12 text-slate-400">Loading employees...</div>
      ) : sortedUsers.length === 0 ? (
        <div className="text-center py-12">
          <FileSpreadsheet className="h-12 w-12 text-slate-500 mx-auto mb-4" />
          <p className="text-slate-300 text-lg">No employees found</p>
          <p className="text-slate-400">Upload a file to get started</p>
        </div>
      ) : (
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-700">
                <th className="text-left py-3 px-4 text-slate-400 font-semibold">No.</th>
                <th className="text-left py-3 px-4 text-slate-400 font-semibold">Name</th>
                <th className="text-left py-3 px-4 text-slate-400 font-semibold">Id Badge</th>
                <th className="text-left py-3 px-4 text-slate-400 font-semibold">Position</th>
                <th className="text-left py-3 px-4 text-slate-400 font-semibold">Area</th>
                <th className="text-left py-3 px-4 text-slate-400 font-semibold">Status</th>
                <th className="text-left py-3 px-4 text-slate-400 font-semibold">Progress</th>
                <th className="text-center py-3 px-4 text-slate-400 font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {sortedUsers.map((user, index) => {
                const overallStatus = getUserOverallCompletionStatus(user);
                return (
                <motion.tr 
                  key={user.id} 
                  initial={{ opacity: 0 }} 
                  animate={{ opacity: 1 }} 
                  transition={{ duration: 0.3, delay: index * 0.03 }} 
                  className="border-b border-slate-800 hover:bg-slate-700/50"
                >
                  <td className="py-3 px-4 text-slate-300">{user.no_urut || index + 1}</td>
                  <td className="py-3 px-4 text-white font-medium">{user.name}</td>
                  <td className="py-3 px-4 text-slate-300">{user.id_badge}</td>
                  <td className="py-3 px-4 text-slate-300">{user.position || '-'}</td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                      user.designated_area?.toLowerCase() === 'offshore' 
                        ? 'bg-blue-400/20 text-blue-300' 
                        : 'bg-green-400/20 text-green-300'
                    }`}>
                      {user.designated_area || 'Onshore'}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${user.approved ? 'bg-green-400/20 text-green-300' : 'bg-yellow-400/20 text-yellow-300'}`}>
                      {user.approved ? 'Approved' : 'Pending'}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                        <div className="w-full bg-slate-700 rounded-full h-1.5" title={overallStatus.message}>
                            <div 
                                className={`h-full rounded-full ${overallStatus.status === 'Complete' ? 'bg-green-500' : 'bg-yellow-500'}`} 
                                style={{ width: `${overallStatus.percentage}%` }}
                            ></div>
                        </div>
                        <span className="text-xs text-slate-400 font-semibold w-10 text-right">{overallStatus.percentage}%</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex space-x-1 justify-center">
                      {!user.approved && (
                        <Button onClick={() => handleApproval(user.id)} size="icon" variant="ghost" className="h-7 w-7 text-green-400 hover:bg-green-500/20 hover:text-green-300" title="Approve User"><CheckCircle className="h-4 w-4" /></Button>
                      )}
                      <Button onClick={() => setSelectedUserForImage(user)} size="icon" variant="ghost" className="h-7 w-7 text-slate-400 hover:bg-slate-700 hover:text-white" title="Upload Image"><ImageIcon className="h-4 w-4" /></Button>
                      {user.approved && (
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button size="icon" variant="ghost" className="h-7 w-7 text-slate-400 hover:bg-slate-700 hover:text-white" title="Show QR Code"><QrCode className="h-4 w-4" /></Button>
                          </DialogTrigger>
                          <DialogContent className="sm:max-w-[425px] bg-slate-800 border-slate-700 text-white">
                            <DialogHeader><DialogTitle>QR Code for {user.name}</DialogTitle></DialogHeader>
                            <div className="p-4 bg-white rounded-lg flex justify-center my-4">
                              <QRCode value={`${window.location.origin}/dashboard/${user.id}`} size={256} />
                            </div>
                          </DialogContent>
                        </Dialog>
                      )}
                      <Button onClick={() => navigate(`/dashboard/${user.id}`)} size="icon" variant="ghost" className="h-7 w-7 text-slate-400 hover:bg-slate-700 hover:text-white" title="View Dashboard"><Eye className="h-4 w-4" /></Button>
                      <Button onClick={() => handleLoginAsUser(user.id)} size="icon" variant="ghost" className="h-7 w-7 text-slate-400 hover:bg-slate-700 hover:text-white" title="Login as User"><LogIn className="h-4 w-4" /></Button>
                      <Button onClick={() => onDeleteRequest(user)} size="icon" variant="ghost" className="h-7 w-7 text-red-400 hover:bg-red-500/20 hover:text-red-300" title="Delete User"><Trash2 className="h-4 w-4" /></Button>
                    </div>
                  </td>
                </motion.tr>
              )})}
            </tbody>
          </table>
        </div>
      )}
    </motion.div>
  );
});
EmployeeManagement.displayName = 'EmployeeManagement';

export default EmployeeManagement;