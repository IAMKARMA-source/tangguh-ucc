import React from 'react';
import { motion } from 'framer-motion';
import { User, Building, Briefcase, MapPin, FileText, FileSpreadsheet as FileExcelIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';

const UserProfileCard = React.memo(({ userData, completedModulesCount, totalTrainingModules, overallProgressPercent, onExportPDF, onExportExcel, profileImage }) => {
  if (!userData) return null;

  return (
    <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8 }} className="glass-effect rounded-3xl p-6">
      <div className="text-center mb-6">
        {profileImage ? (
          <img alt="Employee profile picture" className="w-28 h-28 rounded-full object-cover mx-auto mb-4 border-2 border-blue-400 shadow-lg" src={profileImage} />
        ) : (
          <div className="w-28 h-28 bg-gradient-to-br from-green-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg"><User className="h-14 w-14 text-white" /></div>
        )}
        <h2 className="text-2xl font-bold text-white mb-1">{userData.name}</h2>
        <p className="text-blue-300 text-sm mb-2">{userData.id_badge}</p>
      </div>
      <div className="space-y-3 text-sm">
        <div className="flex items-center"><Building className="h-4 w-4 mr-3 text-gray-400" /><span className="text-gray-300">Company:</span><span className="text-white font-semibold ml-auto">{userData.company}</span></div>
        <div className="flex items-center"><Briefcase className="h-4 w-4 mr-3 text-gray-400" /><span className="text-gray-300">Position:</span><span className="text-white font-semibold ml-auto">{userData.position || 'N/A'}</span></div>
        <div className="flex items-center"><MapPin className="h-4 w-4 mr-3 text-gray-400" /><span className="text-gray-300">Area:</span><span className="text-white font-semibold ml-auto">{userData.designated_area}</span></div>
      </div>
      <div className="mt-6">
        <div className="flex justify-between text-sm text-gray-300 mb-2">
          <span>Overall Progress (All Trainings)</span>
          <span className="font-semibold text-green-400">{`${completedModulesCount}/${totalTrainingModules} Passed`}</span>
        </div>
        <div className="w-full bg-gray-700/50 rounded-full h-3.5 border border-gray-600">
          <motion.div initial={{ width: 0 }} animate={{ width: `${overallProgressPercent}%` }} transition={{ duration: 1.5, delay: 0.5 }} className="progress-bar h-full rounded-full"></motion.div>
        </div>
      </div>
      <div className="mt-6 flex space-x-2">
        <Button onClick={onExportPDF} variant="outline" size="sm" className="flex-1 border-sky-500 text-sky-300 hover:bg-sky-500 hover:text-white">
          <FileText className="mr-2 h-4 w-4" /> Export PDF
        </Button>
        <Button onClick={onExportExcel} variant="outline" size="sm" className="flex-1 border-emerald-500 text-emerald-300 hover:bg-emerald-500 hover:text-white">
          <FileExcelIcon className="mr-2 h-4 w-4" /> Export Excel
        </Button>
      </div>
    </motion.div>
  );
});

export default UserProfileCard;