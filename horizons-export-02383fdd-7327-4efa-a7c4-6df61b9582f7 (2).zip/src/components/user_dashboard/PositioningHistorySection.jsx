import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Calendar, AlertTriangle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';

const PositioningHistorySection = React.memo(({ userData }) => {
  const [positionHistory, setPositionHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    const fetchPositionHistory = async () => {
      if (!userData?.id) return;
      
      setIsLoading(true);
      try {
        const { data, error } = await supabase
          .from('position_history')
          .select('*')
          .eq('employee_id', userData.id)
          .order('change_date', { ascending: false });

        if (error) {
          console.error('Error fetching position history:', error);
          toast({ 
            title: "Error Loading History", 
            description: "Could not load positioning history.", 
            variant: "destructive" 
          });
        } else {
          setPositionHistory(data || []);
        }
      } catch (err) {
        console.error('Unexpected error:', err);
        toast({ 
          title: "Unexpected Error", 
          description: "An error occurred while loading position history.", 
          variant: "destructive" 
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchPositionHistory();
  }, [userData?.id, toast]);

  if (!userData) return null;

  return (
    <div className="glass-effect rounded-3xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-semibold text-white flex items-center">
          <MapPin className="h-6 w-6 mr-2 text-blue-400" />
          Positioning History
        </h3>
      </div>

      {isLoading ? (
        <div className="text-center py-4 text-gray-400">
          <div className="animate-pulse">Loading positioning history...</div>
        </div>
      ) : (
        <div className="space-y-3 max-h-48 overflow-y-auto pr-2 custom-scrollbar">
          <motion.div 
            initial={{ opacity: 0, y: 10 }} 
            animate={{ opacity: 1, y: 0 }} 
            className="bg-blue-500/20 border border-blue-500/50 rounded-lg p-3"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <MapPin className="h-4 w-4 mr-2 text-blue-400" />
                <span className="text-white font-medium">Current: {userData.designated_area || 'Not Assigned'}</span>
              </div>
              <span className="text-xs text-blue-300 bg-blue-500/30 px-2 py-1 rounded">Active</span>
            </div>
            <div className="flex items-center mt-1 text-xs text-gray-300">
              <Calendar className="h-3 w-3 mr-1" />
              <span>Since: {new Date().toLocaleDateString()}</span>
            </div>
          </motion.div>

          {positionHistory.length > 0 ? (
            positionHistory.map((record, index) => (
              <motion.div 
                key={record.id}
                initial={{ opacity: 0, y: 10 }} 
                animate={{ opacity: 1, y: 0 }} 
                transition={{ delay: index * 0.1 }}
                className="bg-slate-700/50 border border-slate-600 rounded-lg p-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-2 text-gray-400" />
                    <span className="text-white">
                      {record.previous_designated_area || 'Unknown'} → {record.new_designated_area}
                    </span>
                  </div>
                  <span className="text-xs text-gray-400 bg-slate-600/50 px-2 py-1 rounded">Historical</span>
                </div>
                <div className="flex items-center justify-between mt-1 text-xs text-gray-300">
                  <div className="flex items-center">
                    <Calendar className="h-3 w-3 mr-1" />
                    <span>{new Date(record.change_date).toLocaleDateString()}</span>
                  </div>
                  {record.reason && (
                    <span className="text-gray-400">Reason: {record.reason}</span>
                  )}
                </div>
              </motion.div>
            ))
          ) : (
            <div className="text-center py-6 text-gray-400">
              <AlertTriangle className="h-8 w-8 mx-auto mb-2 text-gray-500" />
              <p className="text-sm">No position change history available.</p>
              <p className="text-xs text-gray-500 mt-1">This employee has maintained their current position.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
});

PositioningHistorySection.displayName = 'PositioningHistorySection';

export default PositioningHistorySection;