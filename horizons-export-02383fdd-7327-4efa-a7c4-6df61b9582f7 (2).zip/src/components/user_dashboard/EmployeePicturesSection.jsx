import React from 'react';
import { Image as ImageIcon } from 'lucide-react';

const EmployeePicturesSection = React.memo(({ images }) => {
  return (
    <div className="glass-effect rounded-3xl p-6">
      <h3 className="text-xl font-semibold text-white mb-4">Employee Pictures</h3>
      {images && images.length > 0 ? (
        <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-2 custom-scrollbar">
          {images.sort((a, b) => new Date(b.created_at) - new Date(a.created_at)).map(img => (
            <a key={img.id} href={img.image_url} target="_blank" rel="noopener noreferrer" className="block rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300">
              <img className="w-full h-24 object-cover" alt="Employee uploaded image" src={img.image_url} />
            </a>
          ))}
        </div>
      ) : (
        <div className="text-center text-gray-400 py-4"><ImageIcon className="mx-auto h-8 w-8 mb-2 text-gray-500" />No pictures uploaded yet.</div>
      )}
    </div>
  );
});

export default EmployeePicturesSection;