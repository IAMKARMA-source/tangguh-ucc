import React from 'react';
import { motion } from 'framer-motion';
import { Badge, CheckCircle, ListX, AlertCircle, BookMarked } from 'lucide-react';
import { normalizeString } from '@/lib/excelHelper';
import { useTrainingDisplayLogic } from '@/hooks/useTrainingDisplayLogic';


const TrainingListSection = React.memo(({ title, icon: Icon, trainings, iconColor, emptyMessage, showBadges = true }) => {
  const { getStatusIcon, getStatusColor } = useTrainingDisplayLogic(true);

  if (!trainings) return null;

  return (
    <div className="bg-white rounded-2xl p-6 border border-slate-200">
      <h3 className={`text-lg font-semibold text-slate-800 mb-4 flex items-center`}>
        <Icon className={`h-5 w-5 mr-2 ${iconColor}`} />
        {title}
      </h3>
      {trainings.length > 0 ? (
        <ul className="space-y-2 max-h-40 overflow-y-auto pr-2 custom-scrollbar text-sm">
          {trainings.map((module) => {
            const StatusIconComponent = getStatusIcon(module.status);
            const statusColorClass = getStatusColor(module.status);
            const statusNormalized = normalizeString(module.status);

            return (
              <li key={module.module} className={`flex items-center p-2 rounded-lg ${statusColorClass.replace('border border-transparent', 'bg-opacity-10')}`}>
                <StatusIconComponent className={`h-4 w-4 mr-2 flex-shrink-0`} />
                <span className="flex-1 truncate text-slate-700" title={module.module}>{module.module}</span>
                {showBadges && module.is_mandatory && statusNormalized !== 'passed' && <Badge className="ml-auto text-xs bg-red-100 text-red-700 border border-red-200">Mandatory</Badge>}
                {showBadges && module.is_priority && !module.is_mandatory && statusNormalized !== 'passed' && <Badge className="ml-auto text-xs bg-amber-100 text-amber-700 border border-amber-200">Priority</Badge>}
                {showBadges && statusNormalized === 'passed' && <Badge className="ml-auto text-xs bg-green-100 text-green-700 border border-green-200">Passed</Badge>}
              </li>
            );
          })}
        </ul>
      ) : (
        <p className="text-slate-500 text-sm">{emptyMessage}</p>
      )}
    </div>
  );
});

export default TrainingListSection;