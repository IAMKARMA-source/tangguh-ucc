import React from 'react';
import { motion } from 'framer-motion';
import { Badge, Calendar, CheckCircle, Clock, ListX, Star, Filter, ChevronDown, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { normalizeString } from '@/lib/excelHelper';
import jsPDF from 'jspdf';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';


const TrainingRecordItem = React.memo(({ record, index, getStatusIcon, getStatusColor, getCategoryTag, userData }) => {
  const StatusIcon = getStatusIcon(record.status);
  const categoryTag = getCategoryTag(record);
  const { toast } = useToast();
  
  let categoryColorClass = 'bg-slate-200 text-slate-600 border-slate-300';
  if (categoryTag === 'M') categoryColorClass = 'bg-red-100 text-red-700 border-red-200';
  else if (categoryTag === 'P1') categoryColorClass = 'bg-amber-100 text-amber-700 border-amber-200';
  else if (categoryTag === 'N/R') categoryColorClass = 'bg-sky-100 text-sky-700 border-sky-200';

  const isControlOfWork = normalizeString(record.module) === 'control of work';
  const cowStatusNormalized = normalizeString(record.status);
  const isCowPassed = cowStatusNormalized === 'passed';
  const canDownloadCowCertificate = isControlOfWork && isCowPassed;

  const downloadCowCertificate = async () => {
    if (!userData) {
      toast({ title: "Error", description: "User data not available to generate certificate.", variant: "destructive" });
      return;
    }

    try {
      const { data: customCertificate, error: fetchError } = await supabase
        .from('custom_certificates')
        .select('file_url, file_name')
        .eq('training_module_name', 'Control of Work')
        .maybeSingle();

      if (fetchError) {
        console.error("Error fetching custom certificate:", fetchError);
      }

      if (customCertificate && customCertificate.file_url) {
        window.open(customCertificate.file_url, '_blank');
        toast({ title: "Custom LOD File Downloaded", description: `Downloading ${customCertificate.file_name}.` });
        return;
      }
    
      const doc = new jsPDF();
      doc.setFontSize(22);
      doc.text("Certificate of Completion", doc.internal.pageSize.getWidth() / 2, 30, { align: "center" });
      doc.setFontSize(16);
      doc.text("Control of Work", doc.internal.pageSize.getWidth() / 2, 50, { align: "center" });
      doc.setFontSize(12);
      doc.text(`This is to certify that`, doc.internal.pageSize.getWidth() / 2, 70, { align: "center" });
      doc.setFontSize(18);
      doc.setFont(undefined, 'bold');
      doc.text(`${userData.name}`, doc.internal.pageSize.getWidth() / 2, 85, { align: "center" });
      doc.setFontSize(12);
      doc.setFont(undefined, 'normal');
      doc.text(`ID Badge: ${userData.id_badge}`, doc.internal.pageSize.getWidth() / 2, 95, { align: "center" });
      doc.text(`has successfully completed the training requirements for Control of Work.`, doc.internal.pageSize.getWidth() / 2, 110, { align: "center", maxWidth: doc.internal.pageSize.getWidth() - 40 });

      if (record.date && isCowPassed) {
        doc.text(`Date of Completion: ${record.date}`, doc.internal.pageSize.getWidth() / 2, 130, { align: "center" });
      }
      
      doc.text(`Verified by: Training Passport System`, 20, doc.internal.pageSize.getHeight() - 30);
      doc.text(`Date Issued: ${new Date().toLocaleDateString()}`, 20, doc.internal.pageSize.getHeight() - 20);
      doc.save(`Control_of_Work_Certificate_${userData.name.replace(/\s/g, '_')}.pdf`);
      toast({ title: "Certificate Downloaded", description: "Generic Control of Work certificate has been generated." });

    } catch (error) {
      toast({ title: "Certificate Error", description: "Could not download certificate.", variant: "destructive" });
      console.error("Error downloading certificate:", error);
    }
  };


  return (
    <motion.div 
      key={record.module + index} 
      initial={{ opacity: 0, y: 20 }} 
      animate={{ opacity: 1, y: 0 }} 
      transition={{ duration: 0.5, delay: index * 0.05 }} 
      className="bg-slate-200/50 rounded-xl p-4 border border-slate-300/70 hover:border-cyan-400/70 transition-colors shadow-sm"
    >
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-3 gap-2">
        <h4 className="text-base md:text-lg font-semibold text-slate-800 flex-1 min-w-0">
          {record.training_code && <span className="text-xs text-cyan-700 mr-2 p-1 bg-cyan-200/70 rounded inline-block mb-1 sm:mb-0">{record.training_code}</span>}
          <span className="block sm:inline truncate" title={record.module}>{record.module}</span>
        </h4>
        <div className="flex items-center space-x-2 flex-shrink-0 self-start sm:self-center">
          {categoryTag && <Badge className={`text-xs py-0.5 px-2 border ${categoryColorClass}`}>{categoryTag === 'P1' && <Star className="h-3 w-3 inline mr-1"/>}{categoryTag}</Badge>}
          <div className={`px-3 py-1 rounded-full text-xs font-medium flex items-center shrink-0 ${getStatusColor(record.status)}`}><StatusIcon className="h-4 w-4 mr-1.5" />{record.status}</div>
        </div>
      </div>
      <div className="flex flex-col sm:flex-row items-center justify-between mb-3 text-slate-500 text-sm gap-2 sm:gap-0">
        <div className="flex items-center"><Calendar className="h-4 w-4 mr-2 text-slate-400" />{record.date || 'N/A'}</div>
        <span className="text-sm text-slate-500">{record.progress || 0}% Complete</span>
      </div>
      <div className="w-full bg-slate-300 rounded-full h-2 border border-slate-300/50 mb-3">
        <motion.div 
          initial={{ width: 0 }} 
          animate={{ width: `${record.progress || 0}%` }} 
          transition={{ duration: 1, delay: index * 0.1 + 0.5 }} 
          className={`h-full rounded-full ${normalizeString(record.status) === 'passed' ? 'bg-green-500' : ['in progress', 'pending'].includes(normalizeString(record.status)) ? 'bg-amber-500' : ['n/r', 'not required'].includes(normalizeString(record.status)) ? 'bg-sky-500' : 'bg-slate-400'}`}>
        </motion.div>
      </div>
      {canDownloadCowCertificate && (
        <Button 
          onClick={downloadCowCertificate} 
          variant="outline" 
          size="sm"
          className="mt-2 w-full sm:w-auto text-emerald-600 border-emerald-400 hover:bg-emerald-400 hover:text-white"
        >
          <Download className="h-4 w-4 mr-2"/>
          Available LOD
        </Button>
      )}
    </motion.div>
  );
});
TrainingRecordItem.displayName = 'TrainingRecordItem';


const TrainingRecordsList = React.memo(({ trainings, trainingFilter, setTrainingFilter, getStatusIcon, getStatusColor, getCategoryTag, userData }) => {
  if (!trainings) return null;

  const getTrainingRecordsTitle = () => {
    if (userData?.designated_area && normalizeString(userData.designated_area) === 'offshore') {
      return 'Training Records Offshore';
    }
    return 'Training Records Onshore';
  };

  return (
    <motion.div initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8, delay: 0.2 }} className="lg:col-span-2">
      <div className="bg-white rounded-2xl p-6 border border-slate-200 h-full">
        <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
          <h3 className="text-xl font-bold text-slate-800">
            {getTrainingRecordsTitle()}
          </h3>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="border-cyan-300 text-cyan-600 hover:bg-cyan-100 hover:text-cyan-700 w-full sm:w-auto">
                <Filter className="mr-2 h-4 w-4" /> Filter: {trainingFilter.charAt(0).toUpperCase() + trainingFilter.slice(1)} <ChevronDown className="ml-2 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56 bg-white border-slate-200 text-slate-800">
              <DropdownMenuRadioGroup value={trainingFilter} onValueChange={setTrainingFilter}>
                <DropdownMenuRadioItem value="all" className="hover:bg-slate-100 focus:bg-slate-200 cursor-pointer">All Trainings</DropdownMenuRadioItem>
                <DropdownMenuRadioItem value="mandatory" className="hover:bg-slate-100 focus:bg-slate-200 cursor-pointer">Mandatory Only</DropdownMenuRadioItem>
                <DropdownMenuRadioItem value="priority" className="hover:bg-slate-100 focus:bg-slate-200 cursor-pointer">Priority Only</DropdownMenuRadioItem>
              </DropdownMenuRadioGroup>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        <div className="space-y-4 max-h-[calc(100vh-20rem)] overflow-y-auto pr-2 custom-scrollbar">
          {trainings.length === 0 && (
            <div className="text-center py-10 text-slate-500">
              <Filter className="h-12 w-12 mx-auto mb-3 text-slate-400" />
              No trainings match the current filter.
            </div>
          )}
          {trainings.map((record, index) => (
            <TrainingRecordItem 
              key={record.module + '_' + index} 
              record={record} 
              index={index} 
              getStatusIcon={getStatusIcon} 
              getStatusColor={getStatusColor} 
              getCategoryTag={getCategoryTag}
              userData={userData}
            />
          ))}
        </div>
      </div>
    </motion.div>
  );
});
TrainingRecordsList.displayName = 'TrainingRecordsList';

export default TrainingRecordsList;