import React, { useState, useEffect, useCallback, lazy, Suspense } from 'react';
import { motion } from 'framer-motion';
import { 
  LogOut, 
  ListTree, 
  FileSpreadsheet as FileIcon,
  Settings,
  Users,
  LayoutGrid,
  FileText,
  BarChart,
  Trash2
} from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';
import { processUploadedData, loadAdminData, processMatrixFile, processMatrixOffshoreFile } from '@/lib/adminDataProcessor';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from '@/components/ui/button';

const AdminStats = lazy(() => import('@/components/admin/AdminStats'));
const EmployeeUpload = lazy(() => import('@/components/admin/EmployeeUpload'));
const EmployeeManagement = lazy(() => import('@/components/admin/EmployeeManagement'));
const ImageUploadDialog = lazy(() => import('@/components/admin/ImageUploadDialog'));
const AdminOverview = lazy(() => import('@/components/admin_dashboard/AdminOverview'));
const UploadSection = lazy(() => import('@/components/admin_dashboard/UploadSection'));
const SiteSettings = lazy(() => import('@/components/admin/SiteSettings'));
const DetailTrainingsUpload = lazy(() => import('@/components/admin/DetailTrainingsUpload'));
const DetailTrainingsDisplay = lazy(() => import('@/components/admin/DetailTrainingsDisplay'));

const LoadingComponentFallback = ({text = "Loading component..."}) => (
  <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-6 mb-8 shadow-lg text-center text-gray-300">
    {text}
  </div>
);

const AdminDashboard = ({ logoUrl: initialLogoUrl }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isUploadingEmployeeData, setIsUploadingEmployeeData] = useState(false);
  const [isUploadingMatrixFile, setIsUploadingMatrixFile] = useState(false);
  const [isUploadingMatrixOffshoreFile, setIsUploadingMatrixOffshoreFile] = useState(false);
  const [isUploadingCertificate, setIsUploadingCertificate] = useState(false);
  const [selectedUserForImage, setSelectedUserForImage] = useState(null);
  const [userToDelete, setUserToDelete] = useState(null);
  const [isDeleteAllDialogOpen, setIsDeleteAllDialogOpen] = useState(false);
  const [currentLogoUrl, setCurrentLogoUrl] = useState(initialLogoUrl || '/favicon.png');
  const [stats, setStats] = useState({ totalUsers: 0, approvedUsers: 0, pendingUsers: 0, fullyCompletedUsers: 0 });
  const [positionStats, setPositionStats] = useState({});
  const [matrixData, setMatrixData] = useState({});
  const [customCertificateFile, setCustomCertificateFile] = useState(null);
  const [matrixFileToUpload, setMatrixFileToUpload] = useState(null);
  const [matrixOffshoreFileToUpload, setMatrixOffshoreFileToUpload] = useState(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [hsseMatrixData, setHsseMatrixData] = useState([]);
  const [hsseTrainingHeaders, setHsseTrainingHeaders] = useState([]);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const tab = params.get('tab');
    if (tab && ['dashboard', 'employees', 'matrix', 'hsse', 'settings'].includes(tab)) {
      setActiveTab(tab);
    }
  }, [location.search]);
  
  const handleTabChange = (tabId) => {
    setActiveTab(tabId);
    navigate(`/admin/dashboard?tab=${tabId}`, { replace: true });
  };

  const fetchData = useCallback(async () => {
    setIsLoading(true);
    try {
      const { employees, matrix, calculatedStats, calculatedPositionStats } = await loadAdminData(supabase, toast);
      setUsers(employees);
      setMatrixData(matrix);
      setStats(calculatedStats);
      setPositionStats(calculatedPositionStats);
    } catch (error) {
       toast({ title: "Error Fetching Data", description: error.message || "Could not load initial admin data.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    const isAuthenticated = localStorage.getItem('adminAuthenticated');
    if (!isAuthenticated) navigate('/admin/login');
    else fetchData();
  }, [navigate, fetchData]);

  useEffect(() => {
    setCurrentLogoUrl(initialLogoUrl || '/favicon.png');
  }, [initialLogoUrl]);

  const handleEmployeeDataUpload = useCallback(async (event) => {
    const file = event.target.files[0];
    if (file) {
      setIsUploadingEmployeeData(true);
      try {
        await processUploadedData(file, supabase, toast, null, fetchData);
      } catch (error) {
        toast({ title: "Employee Data Upload Failed", description: error.message || "An error occurred during file processing.", variant: "destructive" });
      } finally {
        setIsUploadingEmployeeData(false);
        if(event.target) event.target.value = '';
      }
    }
  }, [fetchData, toast]);

  const handleMatrixFileChange = (event) => setMatrixFileToUpload(event.target.files[0]);
  const handleUploadMatrixFile = async () => {
    if (!matrixFileToUpload) return toast({ title: "No File Selected", variant: "default" });
    setIsUploadingMatrixFile(true);
    try {
      await processMatrixFile(matrixFileToUpload, supabase, toast);
      toast({ title: "Matrix Upload Successful" });
      setMatrixFileToUpload(null);
      fetchData(); 
    } catch (error) {
      toast({ title: "Matrix Upload Error", description: error.message, variant: "destructive" });
    } finally {
      setIsUploadingMatrixFile(false);
    }
  };

  const handleMatrixOffshoreFileChange = (event) => setMatrixOffshoreFileToUpload(event.target.files[0]);
  const handleUploadMatrixOffshoreFile = async () => {
    if (!matrixOffshoreFileToUpload) return toast({ title: "No File Selected", variant: "default" });
    setIsUploadingMatrixOffshoreFile(true);
    try {
      await processMatrixOffshoreFile(matrixOffshoreFileToUpload, supabase, toast);
      toast({ title: "Offshore Matrix Upload Successful" });
      setMatrixOffshoreFileToUpload(null);
      fetchData(); 
    } catch (error) {
      toast({ title: "Offshore Matrix Upload Error", description: error.message, variant: "destructive" });
    } finally {
      setIsUploadingMatrixOffshoreFile(false);
    }
  };
  
  const handleAdminImageUpload = useCallback(async (event) => {
    const file = event.target.files[0];
    if (!file || !selectedUserForImage) return;
    const filePath = `employee_avatars/${selectedUserForImage.id}/${Date.now()}.${file.name.split('.').pop()}`;
    const { error: uploadError } = await supabase.storage.from('employee_uploads').upload(filePath, file);
    if (uploadError) return toast({ title: "Upload Error", description: uploadError.message, variant: "destructive" });
    const { data } = supabase.storage.from('employee_uploads').getPublicUrl(filePath);
    const { error: dbError } = await supabase.from('employee_images').insert({ employee_id: selectedUserForImage.id, image_url: data.publicUrl });
    if (dbError) toast({ title: "Success", description: "Image uploaded successfully!" });
    else {
      toast({ title: "Success", description: "Image uploaded successfully!" });
      setSelectedUserForImage(null);
      fetchData(); 
    }
  }, [selectedUserForImage, toast, fetchData]);

  const handleApproval = useCallback(async (userId) => {
    try {
      const { error } = await supabase.from('employees').update({ approved: true }).eq('id', userId);
      if (error) throw error;
      toast({ title: "User Approved!", description: "QR code can now be used." });
      fetchData();
    } catch (error) {
      toast({ title: "Approval Error", description: error.message, variant: "destructive" });
    }
  }, [fetchData, toast]);

  const handleDeleteUser = useCallback(async (userId) => {
    if (!userId) return;
    try {
      await supabase.from('training_records').delete().eq('employee_id', userId);
      await supabase.from('employee_images').delete().eq('employee_id', userId);
      await supabase.from('position_history').delete().eq('employee_id', userId);
      const { error } = await supabase.from('employees').delete().eq('id', userId);
      if (error) throw error;
      toast({ title: "User Deleted", description: "Employee has been removed." });
      fetchData();
    } catch (error) {
      toast({ title: "Delete Error", description: error.message, variant: "destructive" });
    } finally {
      setUserToDelete(null);
    }
  }, [fetchData, toast]);

  const handleDeleteAllUsers = useCallback(async () => {
    try {
      await supabase.from('training_records').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      await supabase.from('employee_images').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      await supabase.from('position_history').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      await supabase.from('employees').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      toast({ title: "All Users Deleted", description: "All employee data has been removed." });
      fetchData();
    } catch (error) {
      toast({ title: "Delete Error", description: error.message, variant: "destructive" });
    } finally {
      setIsDeleteAllDialogOpen(false);
    }
  }, [fetchData, toast]);

  const handleLogout = useCallback(() => {
    localStorage.removeItem('adminAuthenticated');
    navigate('/');
  }, [navigate]);

  const handleCustomCertificateFileChange = (event) => setCustomCertificateFile(event.target.files[0]);
  const handleUploadCustomCertificate = async () => {
    if (!customCertificateFile) return toast({ title: "No File Selected", variant: "default" });
    setIsUploadingCertificate(true);
    try {
      const trainingModuleName = "Control of Work"; 
      const fileName = `custom_lod_file_${trainingModuleName.replace(/\s+/g, '_')}_${Date.now()}.${customCertificateFile.name.split('.').pop()}`;
      const filePath = `custom_certificates/${fileName}`;
      const { error: uploadError } = await supabase.storage.from('employee_uploads').upload(filePath, customCertificateFile, { upsert: true });
      if (uploadError) throw uploadError;
      const { data: publicUrlData } = supabase.storage.from('employee_uploads').getPublicUrl(filePath);
      const { error: dbError } = await supabase.from('custom_certificates').upsert({ training_module_name: trainingModuleName, file_name: customCertificateFile.name, file_url: publicUrlData.publicUrl, uploaded_at: new Date().toISOString() }, { onConflict: 'training_module_name' });
      if (dbError) throw dbError;
      toast({ title: "Upload Successful", description: `Custom LOD file template for ${trainingModuleName} uploaded.` });
      setCustomCertificateFile(null); 
    } catch (error) {
      toast({ title: "Upload Error", description: error.message, variant: "destructive" });
    } finally {
      setIsUploadingCertificate(false);
    }
  };

  const handleMatrixDataProcessed = useCallback((data, headers) => {
    setHsseMatrixData(data);
    setHsseTrainingHeaders(headers);
  }, []);

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <motion.div key="dashboard" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <Suspense fallback={<LoadingComponentFallback text="Loading Stats..."/>}><AdminStats stats={stats} /></Suspense>
            <Suspense fallback={<LoadingComponentFallback text="Loading Overview..."/>}><AdminOverview isLoading={isLoading} positionStats={positionStats} /></Suspense>
          </motion.div>
        );
      case 'employees':
        return (
          <motion.div key="employees" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <Suspense fallback={<LoadingComponentFallback text="Loading Employee Upload..."/>}><EmployeeUpload onFileUpload={handleEmployeeDataUpload} isUploading={isUploadingEmployeeData} users={users} /></Suspense>
            <Suspense fallback={<LoadingComponentFallback text="Loading Employee Management..."/>}><EmployeeManagement users={users} isLoading={isLoading} loadUsers={fetchData} handleApproval={handleApproval} setSelectedUserForImage={setSelectedUserForImage} navigate={navigate} onDeleteRequest={setUserToDelete} onDeleteAllRequest={() => setIsDeleteAllDialogOpen(true)} /></Suspense>
          </motion.div>
        );
      case 'matrix':
        return (
          <motion.div key="matrix" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Suspense fallback={<LoadingComponentFallback text="Loading Onshore Matrix Upload..."/>}><UploadSection title="Upload Position Training Matrix" icon={ListTree} iconColor="text-purple-400" isUploading={isUploadingMatrixFile} onFileChange={handleMatrixFileChange} onUpload={handleUploadMatrixFile} selectedFile={matrixFileToUpload} accept=".xlsx,.xls" inputId="matrix-file-upload-input" info={{ title: "Onshore Matrix File:", list: ["Defines M/P1/N/R trainings per position for ONSHORE.", "Sheet must be named \"Matrix\".", "Overwrites existing onshore matrix rules."] }} /></Suspense>
              <Suspense fallback={<LoadingComponentFallback text="Loading Offshore Matrix Upload..."/>}><UploadSection title="Upload Position Training Matrix Offshore" icon={ListTree} iconColor="text-cyan-400" isUploading={isUploadingMatrixOffshoreFile} onFileChange={handleMatrixOffshoreFileChange} onUpload={handleUploadMatrixOffshoreFile} selectedFile={matrixOffshoreFileToUpload} accept=".xlsx,.xls" inputId="matrix-offshore-file-upload-input" info={{ title: "Offshore Matrix File:", list: ["Defines M/P1/N/R trainings per position for OFFSHORE.", "Sheet must be named \"Matrix_Offshore\".", "Overwrites existing offshore matrix rules."] }} /></Suspense>
            </div>
          </motion.div>
        );
      case 'hsse':
        return (
          <motion.div key="hsse" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <Suspense fallback={<LoadingComponentFallback text="Loading HSSE Upload..."/>}><DetailTrainingsUpload onMatrixDataProcessed={handleMatrixDataProcessed} /></Suspense>
            <Suspense fallback={<LoadingComponentFallback text="Loading HSSE Matrix..."/>}><DetailTrainingsDisplay matrixData={hsseMatrixData} trainingHeaders={hsseTrainingHeaders} /></Suspense>
          </motion.div>
        );
      case 'settings':
        return (
          <motion.div key="settings" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Suspense fallback={<LoadingComponentFallback text="Loading Site Settings..."/>}><SiteSettings currentLogoUrl={currentLogoUrl} setCurrentLogoUrl={setCurrentLogoUrl} toast={toast} /></Suspense>
              <Suspense fallback={<LoadingComponentFallback text="Loading LOD Upload..."/>}><UploadSection title="Upload File LOD" icon={FileIcon} iconColor="text-emerald-400" isUploading={isUploadingCertificate} onFileChange={handleCustomCertificateFileChange} onUpload={handleUploadCustomCertificate} selectedFile={customCertificateFile} accept=".doc,.docx,.pdf" inputId="custom-certificate-upload-input" info={{ title: "LOD File Information:", list: ["Used for \"Control of Work\" LOD.", "Replaces existing LOD file.", "System falls back to generic PDF if no file is uploaded."] }} /></Suspense>
            </div>
          </motion.div>
        );
      default:
        return null;
    }
  };

  const TabButton = ({ id, label, icon: Icon }) => (
    <Button
      variant="ghost"
      onClick={() => handleTabChange(id)}
      className={`flex-1 justify-center text-sm md:text-base transition-all duration-300 ${activeTab === id ? 'bg-white/10 text-white' : 'text-slate-400 hover:bg-white/5 hover:text-white'}`}
    >
      <Icon className="h-4 w-4 mr-2" />
      {label}
    </Button>
  );

  return (
    <>
      <div className="min-h-screen bg-slate-900 text-slate-100">
        <header className="sticky top-0 z-40 bg-slate-900/70 backdrop-blur-lg border-b border-slate-700">
          <div className="container mx-auto px-4 h-16 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {currentLogoUrl && <img src={currentLogoUrl} alt="Site Logo" className="h-8 w-auto rounded" onError={(e) => e.target.style.display='none'}/>}
              <h1 className="text-xl font-bold text-white hidden sm:block">Admin Dashboard</h1>
            </div>
            <div className="flex items-center space-x-2">
              <Button onClick={handleLogout} variant="outline" size="sm" className="border-red-500/50 text-red-400 hover:bg-red-500/20 hover:text-red-300">
                <LogOut className="mr-2 h-4 w-4" /> Logout
              </Button>
            </div>
          </div>
        </header>

        <main className="container mx-auto px-4 py-8">
          <div className="relative h-64 md:h-80 rounded-2xl overflow-hidden mb-8">
            <img  alt="Modern city skyline with skyscrapers" className="absolute inset-0 w-full h-full object-cover" src="https://images.unsplash.com/photo-1659862202624-babd5abcdac1" />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/60 to-transparent"></div>
            <div className="absolute inset-0 flex flex-col justify-end p-8">
              <motion.h2 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.2 }}
                className="text-4xl md:text-5xl font-extrabold text-white tracking-tight"
              >
                Training Management
              </motion.h2>
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.4 }}
                className="mt-2 text-lg text-slate-300 max-w-2xl"
              >
                Oversee, manage, and track all employee training records and compliance from a unified dashboard.
              </motion.p>
            </div>
          </div>

          <div className="bg-slate-800/50 border border-slate-700 rounded-full p-1 flex items-center space-x-1 mb-8">
            <TabButton id="dashboard" label="Dashboard" icon={LayoutGrid} />
            <TabButton id="employees" label="Employees" icon={Users} />
            <TabButton id="matrix" label="Position Matrix" icon={BarChart} />
            <TabButton id="hsse" label="HSSE Matrix" icon={FileText} />
            <TabButton id="settings" label="Settings" icon={Settings} />
          </div>

          {renderContent()}
        </main>
      </div>

      <Suspense fallback={null}>
        <ImageUploadDialog selectedUserForImage={selectedUserForImage} setSelectedUserForImage={setSelectedUserForImage} handleAdminImageUpload={handleAdminImageUpload} />
      </Suspense>
      <AlertDialog open={!!userToDelete} onOpenChange={() => setUserToDelete(null)}>
        <AlertDialogContent className="bg-slate-800 border-red-500 text-white">
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription className="text-slate-400">
              This action cannot be undone. This will permanently delete the user <span className="font-bold text-white">{userToDelete?.name}</span> and all associated data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => handleDeleteUser(userToDelete?.id)} className="bg-red-600 text-white hover:bg-red-700">
              Yes, delete user
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <AlertDialog open={isDeleteAllDialogOpen} onOpenChange={setIsDeleteAllDialogOpen}>
        <AlertDialogContent className="bg-slate-800 border-red-500 text-white">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete All User Data?</AlertDialogTitle>
            <AlertDialogDescription className="text-slate-400">
              This is a critical action and cannot be undone. This will permanently delete ALL employees, their training records, and images. Are you sure you want to proceed?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteAllUsers} className="bg-red-600 text-white hover:bg-red-700">
              Yes, Delete All Data
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default AdminDashboard;