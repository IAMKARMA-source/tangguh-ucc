import React, { useEffect, useRef, useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Camera, ArrowLeft, Scan } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import QrScanner from 'qr-scanner';
import { supabase } from '@/lib/supabase';

const QRScannerPage = () => {
  const navigate = useNavigate();
  const videoRef = useRef(null);
  const qrScannerRef = useRef(null);
  const [isScanning, setIsScanning] = useState(false);
  const [hasPermission, setHasPermission] = useState(null);
  const { toast } = useToast();

  const restartScanner = useCallback(() => {
    if (qrScannerRef.current && !qrScannerRef.current.isScanning()) {
      qrScannerRef.current.start().then(() => {
        setIsScanning(true);
      }).catch(err => {
        toast({
          title: "Scanner Error",
          description: "Could not restart the QR scanner.",
          variant: "destructive"
        });
      });
    }
  }, [toast]);

  const handleScanResult = useCallback(async (result) => {
    if (result && result.data) {
      if (qrScannerRef.current) {
        qrScannerRef.current.stop();
      }
      setIsScanning(false);
      let userId = null;

      try {
        const url = new URL(result.data);
        const pathParts = url.pathname.split('/');
        
        const dashboardIndex = pathParts.findIndex(part => part.toLowerCase() === 'dashboard');
        if (dashboardIndex !== -1 && pathParts.length > dashboardIndex + 1) {
          userId = pathParts[dashboardIndex + 1];
        } else {
           const profileIndex = pathParts.findIndex(part => part.toLowerCase() === 'profile');
           if (profileIndex !== -1 && pathParts.length > profileIndex + 1) {
             userId = pathParts[profileIndex + 1];
           }
        }

      } catch (e) {
        if (typeof result.data === 'string' && result.data.match(/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/i)) {
          userId = result.data;
        }
      }
      
      if (userId) {
        try {
          const { data: employee, error } = await supabase
            .from('employees')
            .select('id, approved')
            .eq('id', userId)
            .single();

          if (error || !employee) {
            toast({
              title: "Invalid User ID",
              description: "The scanned QR code does not correspond to a valid user.",
              variant: "destructive",
              duration: 3000
            });
            setTimeout(restartScanner, 2000);
            return;
          }

          if (!employee.approved) {
            toast({
              title: "User Not Approved",
              description: "This employee's profile is pending approval and cannot be viewed yet.",
              variant: "destructive",
              duration: 3000
            });
            setTimeout(restartScanner, 2000);
            return;
          }

          toast({
            title: "QR Code Scanned!",
            description: "Redirecting to employee dashboard...",
          });
          
          setTimeout(() => {
            navigate(`/dashboard/${userId}`);
          }, 500);
        } catch (e) {
          toast({
            title: "Network Error",
            description: "Could not verify user due to a network issue. Please try again.",
            variant: "destructive",
            duration: 3000
          });
          setTimeout(restartScanner, 2000);
        }
      } else {
        toast({
          title: "Invalid QR Code",
          description: "This QR code is not valid for this system. Please scan a valid employee QR code.",
          variant: "destructive",
          duration: 3000
        });
        setTimeout(restartScanner, 2000);
      }
    }
  }, [navigate, toast, restartScanner]);

  const requestCameraPermission = useCallback(async () => {
    try {
      if (!videoRef.current) return;
      await QrScanner.hasCamera();
      setHasPermission(true);

      qrScannerRef.current = new QrScanner(
        videoRef.current,
        handleScanResult,
        {
          highlightScanRegion: true,
          highlightCodeOutline: true,
          preferredCamera: 'environment'
        }
      );

      await qrScannerRef.current.start();
      setIsScanning(true);
    } catch (error) {
      setHasPermission(false);
      let description = "Please allow camera access in your browser settings to scan QR codes.";
      if (error && error.name === 'NotAllowedError') {
        description = "Camera access was denied. Please enable it in your browser settings.";
      } else if (error && error.name === 'NotFoundError') {
        description = "No camera found. Please ensure a camera is connected and enabled.";
      }
      toast({
        title: "Camera Access Issue",
        description: description,
        variant: "destructive"
      });
    }
  }, [handleScanResult, toast]);

  useEffect(() => {
    requestCameraPermission();

    return () => {
      if (qrScannerRef.current) {
        qrScannerRef.current.stop();
        qrScannerRef.current.destroy();
        qrScannerRef.current = null;
      }
    };
  }, [requestCameraPermission]);

  const handleManualInput = () => {
    const demoUserId = 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11'; 
    
    toast({
      title: "Demo Mode",
      description: "Loading demo employee dashboard...",
    });
    
    setTimeout(() => {
      navigate(`/dashboard/${demoUserId}`);
    }, 1000);
  };

  const backgroundPattern = "data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%239C92AC' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E";

  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <div 
          className="absolute inset-0 opacity-20"
          style={{ backgroundImage: `url("${backgroundPattern}")` }}
        ></div>
      </div>

      <div className="relative z-10 container mx-auto px-4 py-8 flex flex-col h-screen">
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex items-center justify-between mb-8"
        >
          <Button
            onClick={() => navigate('/')}
            variant="outline"
            className="border-purple-500 text-purple-300 hover:bg-purple-500 hover:text-white"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <h1 className="text-xl md:text-3xl font-bold text-white">QR Scanner</h1>
          <div className="w-20 md:w-24"></div> {/* Spacer */}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="max-w-md mx-auto w-full flex-grow flex flex-col justify-center"
        >
          <div className="glass-effect rounded-3xl p-4 md:p-6 mb-8">
            <div className="relative aspect-square rounded-2xl overflow-hidden bg-black mb-6">
              <video
                ref={videoRef}
                className="w-full h-full object-cover"
                playsInline
                muted
              />
              {hasPermission === false && (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70 text-center p-4">
                    <Camera className="h-12 w-12 text-red-500 mb-4" />
                    <h3 className="text-white text-lg font-semibold">Camera Access Needed</h3>
                    <p className="text-gray-300 text-sm mb-4">Please grant camera permissions to continue.</p>
                    <Button onClick={requestCameraPermission}>Retry Granting Permission</Button>
                </div>
              )}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="relative w-48 h-48 md:w-64 md:h-64">
                  <div className="absolute -top-1 -left-1 w-10 h-10 border-t-4 border-l-4 border-blue-400 rounded-tl-lg"></div>
                  <div className="absolute -top-1 -right-1 w-10 h-10 border-t-4 border-r-4 border-blue-400 rounded-tr-lg"></div>
                  <div className="absolute -bottom-1 -left-1 w-10 h-10 border-b-4 border-l-4 border-blue-400 rounded-bl-lg"></div>
                  <div className="absolute -bottom-1 -right-1 w-10 h-10 border-b-4 border-r-4 border-blue-400 rounded-br-lg"></div>
                  
                  {isScanning && (
                    <div className="absolute top-0 left-1/2 w-1 h-full bg-blue-400/70 scanner-line"></div>
                  )}
                </div>
              </div>
            </div>

            <div className="text-center">
              <Scan className="h-10 w-10 md:h-12 md:w-12 text-blue-400 mx-auto mb-4 floating-animation" />
              <h2 className="text-lg md:text-xl font-semibold text-white mb-2">
                {isScanning ? 'Scanning for QR Code...' : hasPermission === null ? 'Initializing Camera...' : hasPermission === true ? 'Camera Paused or Scan Complete' : 'Camera Access Denied'}
              </h2>
              <p className="text-gray-300 text-sm md:text-base">
                {hasPermission === true ? 'Position the QR code within the frame or wait for redirection.' : 'Check camera permissions if scanning does not start.'}
              </p>
            </div>
          </div>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="text-center"
          >
            <Button
              onClick={handleManualInput}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 transform hover:scale-105 transition-all duration-300"
            >
              <Camera className="mr-2 h-5 w-5" />
              Try Demo Dashboard
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
};

export default QRScannerPage;