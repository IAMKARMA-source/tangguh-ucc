import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { QrCode, Shield, Users, Zap, ChevronDown, LogIn, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const HomePage = ({ logoUrl }) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [currentLogoUrl, setCurrentLogoUrl] = useState(logoUrl || '/favicon.png');

  useEffect(() => {
    setCurrentLogoUrl(logoUrl || '/favicon.png');
  }, [logoUrl]);

  useEffect(() => {
    const fetchEmployeeCount = async () => {
      try {
        const { error } = await supabase
          .from('employees')
          .select('*', { count: 'exact', head: true });
        if (error) {
          console.error('Error fetching employee count:', error);
          if (error.message.includes('Failed to fetch')) {
            toast({
              title: "Network Error",
              description: "Could not connect to the database. Please check your internet connection or if the service is active.",
              variant: "destructive"
            });
          }
        }
      } catch (e) {
        console.error('Caught error fetching employee count:', e);
        toast({
          title: "Application Error",
          description: "An unexpected error occurred while fetching data.",
          variant: "destructive"
        });
      }
    };
    fetchEmployeeCount();

    const handleLogoUpdate = event => {
      setCurrentLogoUrl(event.detail.logoUrl + `?t=${new Date().getTime()}`);
    };
    window.addEventListener('logoUpdated', handleLogoUpdate);
    return () => window.removeEventListener('logoUpdated', handleLogoUpdate);
  }, [toast]);

  const NavLink = ({ children, href = "#" }) => (
    <a href={href} className="flex items-center text-slate-600 hover:text-slate-900 transition-colors">
      {children} <ChevronDown className="h-4 w-4 ml-1" />
    </a>
  );

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-800">
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-lg border-b border-slate-200">
        <div className="container mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <div className="flex items-center space-x-3">
              {currentLogoUrl && <img src={currentLogoUrl} alt="Site Logo" className="h-8 w-auto" onError={(e) => e.target.style.display='none'}/>}
              <span className="text-2xl font-bold text-slate-900">SmarTangguh</span>
            </div>
            <nav className="hidden md:flex items-center space-x-6 font-medium">
              <DropdownMenu>
                <DropdownMenuTrigger className="flex items-center text-slate-600 hover:text-slate-900 transition-colors focus:outline-none">
                  Produk <ChevronDown className="h-4 w-4 ml-1" />
                </DropdownMenuTrigger>
                <DropdownMenuContent className="bg-white border-slate-200">
                  <DropdownMenuItem onSelect={() => window.open('https://tangguhucc-project.id/', '_blank')} className="cursor-pointer">
                    Fitur &gt; Visitor Induction Online
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <NavLink>Sumber Daya</NavLink>
              <NavLink>Tentang</NavLink>
            </nav>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" className="hidden sm:inline-flex">
              ID <ChevronDown className="h-4 w-4 ml-1" />
            </Button>
            <Button variant="outline" className="hidden sm:inline-flex" onClick={() => navigate('/admin/login')}>
              <LogIn className="h-4 w-4 mr-2" /> Log In
            </Button>
            <Button className="bg-green-600 hover:bg-green-700 text-white" onClick={() => navigate('/scanner')}>
              Jadwalkan Demo
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-grow">
        <div className="relative h-[600px] flex items-center justify-center text-white">
          <img  alt="Modern city skyline with tall glass buildings" className="absolute inset-0 w-full h-full object-cover" src="https://images.unsplash.com/photo-1683774963237-a6576c3a62cd" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/30 to-transparent"></div>
          <div className="relative z-10 container mx-auto px-4 text-center">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4"
            >
              Digitalisasikan proses kerja proyek dan manfaatkan data lapangan Anda
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.4 }}
              className="mt-2 text-lg md:text-xl text-slate-200 max-w-3xl mx-auto"
            >
              Software manajemen proyek untuk meningkatkan quality, safety, dan produktivitas
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.6 }}
              className="mt-8 flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Button size="lg" className="bg-green-600 hover:bg-green-700 text-white text-lg px-8 py-6" onClick={() => navigate('/scanner')}>
                <QrCode className="mr-2 h-5 w-5" /> JADWALKAN DEMO
              </Button>
              <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-slate-900 text-lg px-8 py-6" onClick={() => navigate('/admin/login')}>
                <Shield className="mr-2 h-5 w-5" /> LIHAT PAKET HARGA
              </Button>
            </motion.div>
          </div>
        </div>

        <div className="bg-slate-50 py-20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900">Platform Terintegrasi untuk Konstruksi</h2>
              <p className="mt-4 text-lg text-slate-600 max-w-2xl mx-auto">Satu platform untuk mengelola semua proses di lapangan.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { icon: QrCode, title: 'QR Scanner', description: 'Scan employee QR codes instantly' },
                { icon: Users, title: 'Employee Tracking', description: 'Monitor training progress in real-time' },
                { icon: Shield, title: 'Admin Control', description: 'Secure admin dashboard for data management' },
                { icon: Zap, title: 'Instant Updates', description: 'Real-time progress tracking and notifications' }
              ].map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-white rounded-lg p-8 text-center shadow-md hover:shadow-xl transition-shadow"
                >
                  <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-green-100 flex items-center justify-center">
                    <feature.icon className="h-8 w-8 text-green-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">{feature.title}</h3>
                  <p className="text-slate-600">{feature.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-slate-800 text-slate-300">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
            <div>
              <h4 className="font-semibold text-white mb-4">PRODUK</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="https://tangguhucc-project.id/" target="_blank" rel="noopener noreferrer" className="hover:text-white">Visitor Induction Online</a></li>
                <li><a href="#" className="hover:text-white">Quality</a></li>
                <li><a href="#" className="hover:text-white">Safety</a></li>
                <li><a href="#" className="hover:text-white">Laporan</a></li>
                <li><a href="#" className="hover:text-white">Tenaga Kerja</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">INDUSTRI</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white">Bangunan</a></li>
                <li><a href="#" className="hover:text-white">Infrastruktur</a></li>
                <li><a href="#" className="hover:text-white">Real Estat</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">SUMBER DAYA</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white">Blog</a></li>
                <li><a href="#" className="hover:text-white">Studi Kasus</a></li>
                <li><a href="#" className="hover:text-white">Webinar</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">TENTANG</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white">Misi Kami</a></li>
                <li><a href="#" className="hover:text-white">Tim Kami</a></li>
                <li><a href="#" className="hover:text-white">Karier</a></li>
              </ul>
            </div>
            <div className="col-span-2 lg:col-span-1">
              <h4 className="font-semibold text-white mb-4">KONTAK</h4>
              <p className="text-sm">Jl. Jenderal Sudirman Kav. 52-53, Jakarta Selatan, Indonesia</p>
            </div>
          </div>
          <div className="mt-12 border-t border-slate-700 pt-8 flex flex-col sm:flex-row justify-between items-center text-sm">
            <p>&copy; 2025 SmarTangguh. All rights reserved.</p>
            <div className="flex space-x-4 mt-4 sm:mt-0">
              <a href="#" className="hover:text-white">Privacy Policy</a>
              <a href="#" className="hover:text-white">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;