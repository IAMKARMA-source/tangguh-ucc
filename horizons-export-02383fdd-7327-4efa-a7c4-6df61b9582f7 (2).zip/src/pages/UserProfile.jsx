import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, User, Calendar, CheckCircle, Clock, Upload, Badge, Building, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from '@/components/ui/use-toast';

const UserProfile = () => {
  const navigate = useNavigate();
  const { userId } = useParams();
  const [userData, setUserData] = useState(null);
  const [userImages, setUserImages] = useState([]);

  const trainingModules = [
    'Project Induction', 'Ranger', 'Guardian', 'Mechanical Lifting',
    'Scaffolding Safety Awareness', 'Electrical Safety', 'Safe Welding Cutting and Grinding',
    'Ground Disturbance Safety', 'Defensive Driving Training', 'Marine Safety',
    'Strong HSE (Only HSE personnel)', 'Work at Height (theory and practical)',
    'Confined Space Entry (theory and practical)', 'Commissioning HSE Awareness',
    'Control of Work', 'Biodiversity Conservation (enviro)', 'Waste Management (enviro)',
    'Spill Response (enviro)', 'Malaria Control (Health)',
    'Control of Substance Hazardous to Health (Industrial)', 'Black Id',
    'Process Safety Fundamental', 'E-CoW'
  ];

  useEffect(() => {
    const loadUserData = () => {
      const storedUsers = JSON.parse(localStorage.getItem('uccUsers') || '[]');
      let user = storedUsers.find(u => u.id === userId);

      if (!user) {
        // Create a detailed demo user if not found
        user = {
          id: userId,
          name: 'John Doe (Demo)',
          position: 'Offshore Worker',
          company: 'Tangguh UCC',
          idBadge: 'DEMO-001',
          designatedArea: 'Offshore Platform A',
          trainingRecords: trainingModules.map((moduleName, index) => ({
            module: moduleName,
            status: index % 3 === 0 ? 'Passed' : (index % 3 === 1 ? 'In Progress' : 'Pending'),
            date: index % 3 === 0 ? '2025-06-10' : '',
            progress: index % 3 === 0 ? 100 : (index % 3 === 1 ? 50 : 0),
          }))
        };
      }
      setUserData(user);
    };

    const loadUserImages = () => {
      const storedImages = JSON.parse(localStorage.getItem(`userImages_${userId}`) || '[]');
      setUserImages(storedImages);
    };

    loadUserData();
    loadUserImages();
  }, [userId]);

  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const newImage = {
          id: Date.now(),
          url: e.target.result,
          name: file.name,
          uploadDate: new Date().toISOString().split('T')[0],
          type: 'user_upload'
        };
        
        const updatedImages = [...userImages, newImage];
        setUserImages(updatedImages);
        localStorage.setItem(`userImages_${userId}`, JSON.stringify(updatedImages));
        
        toast({
          title: "Image Uploaded Successfully!",
          description: "Your image has been added to your profile.",
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case 'passed': return 'text-green-400 bg-green-400/20';
      case 'in progress': return 'text-yellow-400 bg-yellow-400/20';
      default: return 'text-gray-400 bg-gray-400/20';
    }
  };

  const getStatusIcon = (status) => {
    switch (status.toLowerCase()) {
      case 'passed': return CheckCircle;
      case 'in progress': return Clock;
      default: return Clock;
    }
  };

  if (!userData) {
    return <div className="min-h-screen flex items-center justify-center"><div className="text-white text-xl">Loading...</div></div>;
  }

  const completedModules = userData.trainingRecords.filter(r => r.status.toLowerCase() === 'passed').length;
  const totalModules = userData.trainingRecords.length;
  const overallProgress = totalModules > 0 ? Math.round((completedModules / totalModules) * 100) : 0;

  const backgroundPattern = "data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%239C92AC' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E";

  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900" style={{ backgroundImage: `url("${backgroundPattern}")` }}></div>
      <div className="relative z-10 container mx-auto px-4 py-8">
        <motion.div initial={{ opacity: 0, y: -30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="flex items-center justify-between mb-8">
          <Button onClick={() => navigate('/scanner')} variant="outline" className="border-purple-500 text-purple-300 hover:bg-purple-500 hover:text-white">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Scanner
          </Button>
          <h1 className="text-3xl font-bold text-white">Employee Profile</h1>
          <div className="w-32"></div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8 }} className="lg:col-span-1">
            <div className="glass-effect rounded-3xl p-6 mb-6">
              <div className="text-center mb-6">
                <div className="w-24 h-24 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-4"><User className="h-12 w-12 text-white" /></div>
                <h2 className="text-2xl font-bold text-white mb-2">{userData.name}</h2>
                <p className="text-purple-300 mb-1">{userData.position}</p>
              </div>
              <div className="space-y-3 text-sm">
                <div className="flex items-center"><Badge className="h-4 w-4 mr-3 text-gray-400" /><span className="text-gray-300">ID Badge:</span><span className="text-white font-semibold ml-auto">{userData.idBadge}</span></div>
                <div className="flex items-center"><Building className="h-4 w-4 mr-3 text-gray-400" /><span className="text-gray-300">Company:</span><span className="text-white font-semibold ml-auto">{userData.company}</span></div>
                <div className="flex items-center"><MapPin className="h-4 w-4 mr-3 text-gray-400" /><span className="text-gray-300">Area:</span><span className="text-white font-semibold ml-auto">{userData.designatedArea}</span></div>
              </div>
              <div className="mt-6">
                <div className="flex justify-between text-sm text-gray-300 mb-2"><span>Overall Progress</span><span>{completedModules}/{totalModules} Passed</span></div>
                <div className="w-full bg-gray-700 rounded-full h-3"><motion.div initial={{ width: 0 }} animate={{ width: `${overallProgress}%` }} transition={{ duration: 1.5, delay: 0.5 }} className="progress-bar h-3 rounded-full"></motion.div></div>
              </div>
            </div>
            <div className="glass-effect rounded-3xl p-6">
              <h3 className="text-xl font-semibold text-white mb-4">Upload Images</h3>
              <label className="block">
                <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                <div className="border-2 border-dashed border-purple-500 rounded-lg p-6 text-center cursor-pointer hover:border-purple-400 transition-colors"><Upload className="h-8 w-8 text-purple-400 mx-auto mb-2" /><p className="text-purple-300">Click to upload</p><p className="text-sm text-gray-400">PNG, JPG up to 10MB</p></div>
              </label>
              {userImages.length > 0 && (
                <div className="mt-4 space-y-2"><h4 className="text-sm font-semibold text-gray-300">Your Images:</h4><div className="grid grid-cols-2 gap-2">{userImages.map(img => (<div key={img.id} className="relative"><img src={img.url} alt={img.name} className="w-full h-20 object-cover rounded-lg" /><div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white text-xs p-1 rounded-b-lg">{img.uploadDate}</div></div>))}</div></div>
              )}
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8, delay: 0.2 }} className="lg:col-span-2">
            <div className="glass-effect rounded-3xl p-6">
              <h3 className="text-2xl font-bold text-white mb-6">Training Records</h3>
              <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-2">
                {userData.trainingRecords.map((record, index) => {
                  const StatusIcon = getStatusIcon(record.status);
                  return (
                    <motion.div key={index} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: index * 0.05 }} className="bg-slate-800/50 rounded-2xl p-4 border border-slate-700 hover:border-purple-500 transition-colors">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="text-lg font-semibold text-white">{record.module}</h4>
                        <div className={`px-3 py-1 rounded-full text-sm font-medium flex items-center ${getStatusColor(record.status)}`}><StatusIcon className="h-4 w-4 mr-1" />{record.status}</div>
                      </div>
                      <div className="flex items-center justify-between mb-3 text-gray-300"><div className="flex items-center"><Calendar className="h-4 w-4 mr-2" />{record.date || 'Not started'}</div><span className="text-sm text-gray-400">{record.progress}% Complete</span></div>
                      <div className="w-full bg-gray-700 rounded-full h-2"><motion.div initial={{ width: 0 }} animate={{ width: `${record.progress}%` }} transition={{ duration: 1, delay: index * 0.1 + 0.5 }} className={`h-2 rounded-full ${record.status.toLowerCase() === 'passed' ? 'bg-green-500' : record.status.toLowerCase() === 'in progress' ? 'bg-yellow-500' : 'bg-gray-600'}`}></motion.div></div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;