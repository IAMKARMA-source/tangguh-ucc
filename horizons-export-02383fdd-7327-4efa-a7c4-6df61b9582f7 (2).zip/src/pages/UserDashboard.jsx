import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { motion } from 'framer-motion';
import { User, Clock, AlertTriangle, ListChecks, ListX, ShieldCheck, BookMarked, Home, Award } from 'lucide-react';
import { useParams, useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { getTotalTrainingModulesForArea } from '@/lib/trainingModules';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { normalizeString } from '@/lib/excelHelper';

import UserProfileCard from '@/components/user_dashboard/UserProfileCard';
import TrainingListSection from '@/components/user_dashboard/TrainingListSection';
import EmployeePicturesSection from '@/components/user_dashboard/EmployeePicturesSection';
import TrainingRecordsList from '@/components/user_dashboard/TrainingRecordsList';
import PositioningHistorySection from '@/components/user_dashboard/PositioningHistorySection';

import { useUserData } from '@/hooks/useUserData';
import { useTrainingCalculations } from '@/hooks/useTrainingCalculations';
import { useTrainingDisplayLogic } from '@/hooks/useTrainingDisplayLogic';

const UserDashboard = ({ logoUrl: initialLogoUrl }) => {
  const { userId } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const { userData, isLoading: isUserDataLoading } = useUserData(userId);
  const userTrainingRecords = useMemo(() => userData?.training_records || [], [userData]);

  // Determine if user is offshore for total training modules calculation
  const isOffshore = userData?.designated_area && normalizeString(userData.designated_area) === 'offshore';
  const totalTrainingModules = getTotalTrainingModulesForArea(isOffshore);

  const { 
    completedModulesCount, 
    overallProgressPercent, 
    mandatoryTrainingsList, 
    inhouseTrainingsList,
    thirdPartyTrainingsList
  } = useTrainingCalculations(userTrainingRecords, userData);

  const { getStatusColor, getStatusIcon, getCategoryTag } = useTrainingDisplayLogic();

  const [currentLogoUrl, setCurrentLogoUrl] = useState(initialLogoUrl || '/favicon.png');
  const [trainingFilter, setTrainingFilter] = useState('all'); 
  
  useEffect(() => {
    setCurrentLogoUrl(initialLogoUrl || '/favicon.png');
  }, [initialLogoUrl]);

  const filteredTrainings = useMemo(() => {
    if (!userTrainingRecords) return [];
    return userTrainingRecords.filter(record => {
      if (trainingFilter === 'all') return true;
      if (trainingFilter === 'mandatory') return record.is_mandatory === true;
      if (trainingFilter === 'priority') return record.is_priority === true && record.is_mandatory !== true; 
      return true;
    });
  }, [userTrainingRecords, trainingFilter]);
  
  const backgroundPattern = useMemo(() => "data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%230ADCFE' fill-opacity='0.05'%3E%3Cpath d='M30 0L60 30H0L30 0zm0 60L0 30h60L30 60z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E", []);
  
  const profileImage = useMemo(() => userData?.employee_images && userData.employee_images.length > 0 
    ? userData.employee_images.sort((a, b) => new Date(b.created_at) - new Date(a.created_at))[0].image_url
    : null, [userData?.employee_images]);

  const getLodValue = useCallback((record) => {
    const moduleNormalized = normalizeString(record.module);
    const statusNormalized = normalizeString(record.status);
    const categoryTagValue = getCategoryTag(record);

    if (moduleNormalized === 'control of work') {
      if (statusNormalized === 'passed') {
        return 'Available';
      }
      if (categoryTagValue === 'M') {
        return 'Mandatory (Pending)';
      }
      if (statusNormalized === 'n/a' || statusNormalized === 'n/r' || statusNormalized === 'not required') {
        return 'N/A';
      }
      return 'N/A';
    }
    return 'N/A'; 
  }, [getCategoryTag]);

  const exportToPDF = useCallback(async () => {
    if (!userData) return;
    const doc = new jsPDF();
    
    let startY = 22;

    if (profileImage) {
      try {
        const imgResponse = await fetch(profileImage);
        const imgBlob = await imgResponse.blob();
        const reader = new FileReader();
        
        const promise = new Promise((resolve, reject) => {
          reader.onload = (event) => {
            try {
              const imgData = event.target.result;
              doc.addImage(imgData, 'JPEG', 14, startY, 30, 30); 
              resolve();
            } catch (e) {
              console.error("Error adding image to PDF:", e);
              reject(e);
            }
          };
          reader.onerror = (error) => {
            console.error("FileReader error:", error);
            reject(error);
          };
          reader.readAsDataURL(imgBlob);
        });
        await promise;
        startY += 5; 
      } catch (e) {
        console.error("Failed to load or add profile image to PDF:", e);
        toast({ title: "Image Export Warning", description: "Could not add profile image to PDF.", variant: "default" });
      }
    }
    
    doc.setFontSize(18);
    doc.text(`Training Passport - ${userData.name}`, profileImage ? 50 : 14, startY);
    startY += 8;
    doc.setFontSize(11);
    doc.text(`ID Badge: ${userData.id_badge}`, profileImage ? 50 : 14, startY);
    startY += 6;
    doc.text(`Position: ${userData.position || 'N/A'}`, profileImage ? 50 : 14, startY);
    startY += 6;
    doc.text(`Company: ${userData.company || 'N/A'}`, profileImage ? 50 : 14, startY);
    startY += 10;

    const tableColumn = ["Training List", "Status", "Date", "Category", "LOD"];
    const tableRows = [];

    filteredTrainings.forEach(record => {
      const recordData = [
        record.module,
        record.status || 'N/A',
        record.date || 'N/A', 
        getCategoryTag(record) || 'N/A',
        getLodValue(record), 
      ];
      tableRows.push(recordData);
    });

    doc.autoTable({
      head: [tableColumn],
      body: tableRows,
      startY: startY,
      theme: 'striped',
      headStyles: { fillColor: [0, 122, 204] },
      didParseCell: function (data) {
        if (data.column.dataKey === "Date") { 
            if (data.cell.raw === 'N/A') {
                 data.cell.text = ['N/A'];
            }
        }
      }
    });
    doc.save(`${userData.name}_training_report.pdf`);
    toast({title: "Export Successful", description: "PDF report generated."});
  }, [userData, filteredTrainings, toast, getCategoryTag, getLodValue, profileImage]);

  const exportToExcel = useCallback(() => {
    if (!userData) return;
    const dataToExport = filteredTrainings.map(record => ({
      'Training List': record.module,
      'Status': record.status || 'N/A',
      'Date': record.date || 'N/A', 
      'Category': getCategoryTag(record) || 'N/A',
      'LOD': getLodValue(record), 
      'Progress (%)': record.progress || 0
    }));
    
    const ws = XLSX.utils.json_to_sheet(dataToExport);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Training Records");
    XLSX.writeFile(wb, `${userData.name}_training_report.xlsx`);
    toast({title: "Export Successful", description: "Excel report generated."});
  }, [userData, filteredTrainings, toast, getCategoryTag, getLodValue]);

  if (isUserDataLoading) {
    return <div className="min-h-screen flex items-center justify-center bg-background"><div className="text-white text-xl animate-pulse">Loading Training Passport...</div></div>;
  }
  
  if (!userData && !isUserDataLoading) { 
    return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-background text-white p-4">
            <AlertTriangle className="w-16 h-16 text-red-500 mb-4" />
            <h1 className="text-3xl font-bold mb-2">Employee Profile Unavailable</h1>
            <p className="text-muted-foreground mb-6 text-center">The requested employee profile could not be loaded.<br/>This might be due to an invalid ID, network issues, or the profile not being found.<br/>Please try scanning again or contact support.</p>
            <Button onClick={() => navigate('/')} className="bg-primary text-primary-foreground hover:bg-primary/90">Back to Home</Button>
        </div>
    );
  }

  if (userData?.isPending) { 
     return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-background text-white p-4">
            <Clock className="w-16 h-16 text-yellow-500 mb-4" />
            <h1 className="text-3xl font-bold mb-2">Profile Pending Approval</h1>
            <p className="text-muted-foreground mb-6 text-center">This employee's profile is waiting for admin approval and cannot be viewed yet.</p>
            <Button onClick={() => navigate('/')} className="bg-primary text-primary-foreground hover:bg-primary/90">Back to Home</Button>
        </div>
    );
  }
  
  if (userData && !userData.isPending) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <div className="flex-grow relative overflow-hidden">
          <div className="absolute inset-0" style={{ backgroundImage: `url("${backgroundPattern}")` }}></div>
          <div className="absolute inset-0 bg-gradient-to-b from-background via-transparent to-background"></div>
          <div className="relative z-10 container mx-auto px-4 py-8">
            <motion.div initial={{ opacity: 0, y: -30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="flex items-center justify-center mb-8 text-center">
              {currentLogoUrl && <img src={currentLogoUrl} alt="Site Logo" className="h-12 w-auto mr-4 rounded-md" onError={(e) => e.target.style.display='none'}/>}
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-white">Training Passport</h1>
                <p className="text-cyan-300">Tangguh UCC Project Digitalize</p>
              </div>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-1 space-y-8">
                <UserProfileCard 
                  userData={userData}
                  completedModulesCount={completedModulesCount}
                  totalTrainingModules={totalTrainingModules}
                  overallProgressPercent={overallProgressPercent}
                  onExportPDF={exportToPDF}
                  onExportExcel={exportToExcel}
                  profileImage={profileImage}
                />
                <TrainingListSection 
                  title="Mandatory Training"
                  icon={BookMarked}
                  trainings={mandatoryTrainingsList}
                  iconColor="text-red-400"
                  emptyMessage="All mandatory trainings completed or none assigned."
                  showBadges={true}
                />
                <TrainingListSection 
                  title="Inhouse Training"
                  icon={Home}
                  trainings={inhouseTrainingsList}
                  iconColor="text-purple-400"
                  emptyMessage="No inhouse trainings assigned or all completed."
                  showBadges={false}
                />
                 <TrainingListSection 
                  title="Third Party Training / Certification"
                  icon={Award}
                  trainings={thirdPartyTrainingsList}
                  iconColor="text-amber-400"
                  emptyMessage="No third party trainings or certifications."
                  showBadges={false}
                />
                <div className="glass-effect rounded-3xl p-6 text-center">
                    <ShieldCheck className="h-12 w-12 text-green-400 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-white mb-2">Verified Employee</h3>
                    <p className="text-muted-foreground text-sm">This digital passport is verified and up-to-date as of {new Date().toLocaleDateString()}.</p>
                </div>
                <PositioningHistorySection userData={userData} />
                <EmployeePicturesSection images={userData.employee_images} />
              </div>

              <TrainingRecordsList 
                trainings={filteredTrainings}
                trainingFilter={trainingFilter}
                setTrainingFilter={setTrainingFilter}
                getStatusIcon={getStatusIcon}
                getStatusColor={getStatusColor}
              />
            </div>
          </div>
        </div>
        <footer className="relative z-10 text-center py-4 text-muted-foreground text-sm bg-card/50">
          © 2025 Tangguh UCC
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-white text-xl text-center p-4">
        <AlertTriangle className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
        An unexpected issue occurred while trying to display the dashboard. <br/>Please try refreshing the page or contact support if the problem persists.
      </div>
    </div>
  );
};

export default UserDashboard;